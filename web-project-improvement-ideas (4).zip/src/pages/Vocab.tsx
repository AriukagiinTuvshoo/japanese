import { useMemo, useState } from "react";
import { LEVEL_META, type Level } from "../data/levels";
import { VOCAB, vocabByLevel, type VocabItem } from "../data/vocab";
import { useStore } from "../lib/store";
import { focusLevel } from "../lib/progress";
import { isLearned, isMastered } from "../lib/srs";
import Flashcards, { type FlashItem } from "../components/Flashcards";
import { Button, Card, Empty, LevelTabs, PageHeader, Ruby, Segmented, SpeakButton, levelTone } from "../components/ui";
import { cn } from "../utils/cn";

type Dir = "jm" | "mj";
type Filter = "all" | "new" | "learning" | "mastered";

export default function Vocab() {
  const { state, today } = useStore();
  const [lv, setLv] = useState<Level>(() => focusLevel(state));
  const [dir, setDir] = useState<Dir>("jm");
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [session, setSession] = useState<FlashItem[] | null>(null);

  const now = Date.now();
  const list = vocabByLevel(lv);
  const dueAll = VOCAB.filter((v) => state.srs[v.id] && state.srs[v.id].due <= now);
  const newPool = list.filter((v) => !state.srs[v.id]);
  const newLeft = Math.max(0, state.profile.newPerDay - today.newCards);
  const learned = list.filter((v) => isLearned(state.srs[v.id])).length;
  const mastered = list.filter((v) => isMastered(state.srs[v.id])).length;

  const toItem = (v: VocabItem, isNew: boolean): FlashItem => {
    const word = v.w === v.r ? v.w : `${v.w}{${v.r}}`;
    return dir === "jm"
      ? {
          id: v.id,
          isNew,
          say: v.r,
          front: <Ruby text={word} furigana={false} className="text-[clamp(2.8rem,9vw,4.4rem)] font-black leading-tight text-sumi-900" />,
          back: (
            <div>
              <p className="font-jp text-[1.4rem] font-bold text-shu-600">{v.r}</p>
              <p className="mt-2 text-[1.35rem] font-extrabold text-sumi-900">{v.mn}</p>
              <p className="text-[13.5px] text-sumi-500">{v.en}</p>
            </div>
          ),
        }
      : {
          id: v.id,
          isNew,
          front: (
            <div>
              <p className="text-[clamp(1.7rem,6vw,2.4rem)] font-extrabold leading-tight text-sumi-900">{v.mn}</p>
              <p className="mt-2 text-[13.5px] text-sumi-500">{v.en}</p>
            </div>
          ),
          back: (
            <div className="flex flex-col items-center">
              <Ruby text={word} furigana className="text-[2.8rem] font-black text-sumi-900" />
              <SpeakButton text={v.r} className="mt-3" />
            </div>
          ),
        };
  };

  const startReview = () => setSession(dueAll.slice(0, 60).map((v) => toItem(v, false)));
  const startNew = () => setSession(newPool.slice(0, Math.max(newLeft, 5)).map((v) => toItem(v, true)));

  const shown = useMemo(() => {
    const n = q.trim().toLowerCase();
    return list.filter((v) => {
      const c = state.srs[v.id];
      if (filter === "new" && c) return false;
      if (filter === "learning" && (!c || isMastered(c))) return false;
      if (filter === "mastered" && !isMastered(c)) return false;
      if (!n) return true;
      return [v.w, v.r, v.mn, v.en].some((s) => s.toLowerCase().includes(n));
    });
  }, [list, q, filter, state.srs]);

  if (session) return <Flashcards items={session} title={`${lv} · Үгийн сан`} onExit={() => setSession(null)} />;

  const t = levelTone(lv);

  return (
    <div>
      <PageHeader
        kanji="語"
        eyebrow="Суралцах · Үгийн сан"
        title="Ухаалаг давталттай үгийн сан"
        sub="SRS (spaced repetition) — мартах гэж байхад тань яг тэр үед нь давтуулна. Өдөрт 10 шинэ үг, 15 минутын давталт = жилд 3,000+ үг."
        right={
          <Segmented
            value={dir}
            onChange={setDir}
            options={[
              { id: "jm", label: "日 → Мон" },
              { id: "mj", label: "Мон → 日" },
            ]}
          />
        }
      />

      <LevelTabs value={lv} onChange={setLv} meta={(l) => `${vocabByLevel(l).filter((v) => isLearned(state.srs[v.id])).length}/${vocabByLevel(l).length}`} />

      <div className="mt-5 grid gap-4 md:grid-cols-[1.2fr_1fr]">
        <Card className="relative overflow-hidden p-6">
          <div className="seigaiha pointer-events-none absolute -right-6 bottom-0 h-full w-1/2 text-shu-500/[0.05]" />
          <div className="relative grid grid-cols-2 gap-4 sm:grid-cols-4">
            {[
              { n: dueAll.length, l: "Өнөөдөр давтах", c: "text-shu-600" },
              { n: newPool.length, l: `${lv} шинэ үг`, c: "text-ai-500" },
              { n: learned, l: "Сурсан", c: "text-sumi-900" },
              { n: mastered, l: "Бүрэн эзэмшсэн", c: "text-matcha-600" },
            ].map((s) => (
              <div key={s.l}>
                <p className={cn("text-[2rem] font-extrabold leading-none tabnum", s.c)}>{s.n}</p>
                <p className="mt-1.5 text-[11.5px] font-bold text-sumi-500">{s.l}</p>
              </div>
            ))}
          </div>
          <div className="relative mt-6 flex flex-wrap gap-2">
            <Button onClick={startReview} disabled={dueAll.length === 0}>
              Давтах · {dueAll.length}
            </Button>
            <Button variant="ink" onClick={startNew} disabled={newPool.length === 0}>
              Шинэ үг сурах · {Math.min(newPool.length, Math.max(newLeft, 5))}
            </Button>
          </div>
          {newLeft === 0 && newPool.length > 0 && (
            <p className="relative mt-3 text-[12px] text-sumi-500">Өнөөдрийн шинэ үгийн хязгаарт хүрсэн. Нэмэлт 5 үг сурч болно.</p>
          )}
        </Card>

        <Card className={cn("p-6", t.soft)}>
          <p className={cn("font-mono text-[11px] font-bold uppercase tracking-[0.2em]", t.text)}>{lv} · {LEVEL_META[lv].name}</p>
          <p className="mt-2 text-[14px] leading-relaxed text-sumi-700">
            JLPT {lv}-д ойролцоогоор <b>{LEVEL_META[lv].vocab.toLocaleString()}</b> үг шаардагдана. Энд түвшин бүрийн <b>хамгийн өндөр давтамжтай гол үгс</b> багтсан — эдгээрийг бүрэн эзэмшсэний дараа уншлагаас шинэ үгээ нэмж сурна.
          </p>
          <p className="mt-3 text-[11.5px] text-sumi-500">Санамж: үгийн жагсаалт нь сургалтын баримжаа бөгөөд JLPT-ийн албан ёсны жагсаалт биш (албан ёсны жагсаалт 2010 оноос хойш нийтлэгддэггүй).</p>
        </Card>
      </div>

      <Card className="mt-5 p-4 sm:p-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Хайх: 学校, がっこう, сургууль, school…"
            className="h-11 flex-1 rounded-xl border border-sumi-900/12 bg-white px-4 text-[14px] outline-none transition focus:border-shu-500 focus:ring-4 focus:ring-shu-500/10"
          />
          <Segmented
            value={filter}
            onChange={setFilter}
            options={[
              { id: "all", label: "Бүгд" },
              { id: "new", label: "Шинэ" },
              { id: "learning", label: "Сурч буй" },
              { id: "mastered", label: "Эзэмшсэн" },
            ]}
          />
        </div>

        {shown.length === 0 ? (
          <div className="mt-5">
            <Empty kanji="無" title="Үг олдсонгүй" sub="Шүүлтүүр эсвэл хайлтаа өөрчилнө үү." />
          </div>
        ) : (
          <ul className="mt-4 divide-y divide-sumi-900/[0.07]">
            {shown.map((v) => {
              const c = state.srs[v.id];
              const status = !c ? "new" : isMastered(c) ? "mastered" : "learning";
              return (
                <li key={v.id} className="group flex items-center gap-3 py-3 sm:gap-4">
                  <span
                    title={status}
                    className={cn(
                      "h-2.5 w-2.5 shrink-0 rounded-full",
                      status === "new" ? "bg-sumi-900/15" : status === "mastered" ? "bg-matcha-500" : "bg-kin-400",
                    )}
                  />
                  <div className="w-[38%] min-w-0 sm:w-[30%]">
                    <Ruby text={v.w === v.r ? v.w : `${v.w}{${v.r}}`} furigana className="text-[1.35rem] font-bold text-sumi-900" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[14px] font-bold text-sumi-800">{v.mn}</p>
                    <p className="truncate text-[12px] text-sumi-500">{v.en}</p>
                  </div>
                  {c && <span className="hidden font-mono text-[10.5px] text-sumi-400 sm:block">{c.ivl < 1 ? "<1ө" : `${Math.round(c.ivl)}ө`}</span>}
                  <SpeakButton text={v.r} size="sm" />
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
