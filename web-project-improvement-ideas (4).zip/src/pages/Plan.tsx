import { useMemo } from "react";
import { CUM_HOURS, LEVELS, LEVEL_META, daysUntil, fmtDate, nextJlptDates, type Level } from "../data/levels";
import { useStore } from "../lib/store";
import { Card, PageHeader, Ring, levelTone } from "../components/ui";
import { cn } from "../utils/cn";

const WEEK = [
  { d: "Да", focus: "Үг + Ханз", k: "語" },
  { d: "Мя", focus: "Дүрэм", k: "文" },
  { d: "Лх", focus: "Сонсгол", k: "聴" },
  { d: "Пү", focus: "Үг + Уншлага", k: "読" },
  { d: "Ба", focus: "Дүрэм + Сонсгол", k: "文" },
  { d: "Бя", focus: "Давталт · Алдааны дэвтэр", k: "復" },
  { d: "Ня", focus: "Жишиг шалгалт / Амралт", k: "試" },
];

export default function Plan() {
  const { state, actions } = useStore();
  const p = state.profile;
  const dates = nextJlptDates(new Date(), 4);
  const examDate = p.examDate ? new Date(p.examDate) : dates[0];
  const days = Math.max(1, daysUntil(examDate));

  const calc = useMemo(() => {
    const cur = p.current;
    const startIdx = cur === "zero" ? -1 : LEVELS.indexOf(cur);
    const tIdx = LEVELS.indexOf(p.target);
    const need = Math.max(0, CUM_HOURS[p.target] - CUM_HOURS[cur]);
    const have = (days * p.dailyGoal) / 60;
    const ratio = need === 0 ? 1 : have / need;
    const recMin = Math.ceil((need * 60) / days);
    const valid = tIdx > startIdx;
    return { need: Math.round(need), have: Math.round(have), ratio, recMin, valid };
  }, [p.current, p.target, p.dailyGoal, days]);

  const verdict =
    !calc.valid
      ? { t: "Зорилт одоогийн түвшнээс дээгүүр байх ёстой", c: "text-sumi-600", bg: "bg-washi-200" }
      : calc.ratio >= 1
        ? { t: "Бодитой — хэмнэлээ барь", c: "text-matcha-600", bg: "bg-matcha-50" }
        : calc.ratio >= 0.6
          ? { t: "Эрчимтэй — өдрийн цагаа нэмэх хэрэгтэй", c: "text-kin-600", bg: "bg-kin-50" }
          : { t: "Хэт богино — дараагийн шалгалт эсвэл доод түвшинг сонго", c: "text-shu-600", bg: "bg-shu-50" };

  const focus = LEVEL_META[p.target].focus;
  const phases = [
    { n: "基礎", t: "Суурь", pct: 0.5, d: "Үг, ханз, дүрмийг SRS-ээр өдөр бүр. Шинэ материал голлоно." },
    { n: "応用", t: "Хэрэглээ", pct: 0.35, d: "Уншлага, сонсголын дасгал нэмэгдэнэ. 2 долоо хоногт нэг жишиг шалгалт." },
    { n: "直前", t: "Шалгалтын горим", pct: 0.15, d: "Шинэ материал бага. 7 хоног бүр бүтэн жишиг шалгалт, алдааны дэвтэр." },
  ];
  let acc = 0;
  const phaseDates = phases.map((ph) => {
    const start = new Date();
    start.setDate(start.getDate() + Math.round(days * acc));
    acc += ph.pct;
    const end = new Date();
    end.setDate(end.getDate() + Math.round(days * acc));
    return { ...ph, start, end };
  });

  const sel = "h-11 w-full rounded-xl border border-sumi-900/15 bg-white px-3 text-[14px] font-semibold outline-none focus:border-shu-500";

  return (
    <div>
      <PageHeader
        kanji="計"
        eyebrow="Эхлэл · Төлөвлөгөө"
        title="Миний JLPT төлөвлөгөө"
        sub="Одоогийн түвшин, зорилт, шалгалтын огноо, өдрийн цагаа оруулахад шаардлагатай цаг, бодит байдал, долоо хоногийн хуваарийг тооцоолно."
      />

      <div className="grid gap-5 lg:grid-cols-[360px_1fr]">
        <Card className="self-start p-5 lg:sticky lg:top-6">
          <div className="space-y-4">
            <label className="block">
              <span className="text-[12.5px] font-bold text-sumi-700">Одоогийн түвшин</span>
              <select className={cn(sel, "mt-1.5")} value={p.current} onChange={(e) => actions.setProfile({ current: e.target.value as Level | "zero" })}>
                <option value="zero">Тэг (кана мэдэхгүй)</option>
                {LEVELS.map((l) => (
                  <option key={l} value={l}>
                    {l} хүрсэн
                  </option>
                ))}
              </select>
            </label>
            <div>
              <span className="text-[12.5px] font-bold text-sumi-700">Зорилтот түвшин</span>
              <div className="mt-1.5 grid grid-cols-5 gap-1.5">
                {LEVELS.map((l) => {
                  const t = levelTone(l);
                  return (
                    <button
                      key={l}
                      onClick={() => actions.setProfile({ target: l })}
                      className={cn("rounded-lg border py-2 font-mono text-[13px] font-bold transition", p.target === l ? cn(t.solid, "border-transparent") : "border-sumi-900/12 bg-white/70 text-sumi-600")}
                    >
                      {l}
                    </button>
                  );
                })}
              </div>
            </div>
            <label className="block">
              <span className="text-[12.5px] font-bold text-sumi-700">Шалгалтын огноо</span>
              <select
                className={cn(sel, "mt-1.5")}
                value={p.examDate || dates[0].toISOString().slice(0, 10)}
                onChange={(e) => actions.setProfile({ examDate: e.target.value })}
              >
                {dates.map((d) => (
                  <option key={d.toISOString()} value={d.toISOString().slice(0, 10)}>
                    {fmtDate(d)} · {daysUntil(d)} хоног
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="flex justify-between text-[12.5px] font-bold text-sumi-700">
                Өдөрт суралцах <span className="font-mono tabnum">{p.dailyGoal} мин</span>
              </span>
              <input type="range" min={10} max={240} step={5} value={p.dailyGoal} onChange={(e) => actions.setProfile({ dailyGoal: Number(e.target.value) })} className="mt-2 w-full accent-shu-500" />
            </label>
          </div>
        </Card>

        <div className="space-y-5">
          <Card className="overflow-hidden">
            <div className={cn("grid gap-6 p-6 sm:grid-cols-[auto_1fr] sm:items-center sm:p-8", verdict.bg)}>
              <Ring value={Math.min(1, calc.ratio)} size={120} stroke={10} color={calc.ratio >= 1 ? "#688c45" : calc.ratio >= 0.6 ? "#b88a2d" : "#cc4630"}>
                <span className="text-center">
                  <span className="block text-[1.7rem] font-extrabold leading-none tabnum">{Math.min(999, Math.round(calc.ratio * 100))}%</span>
                  <span className="text-[10.5px] font-bold text-sumi-500">хангалт</span>
                </span>
              </Ring>
              <div>
                <p className={cn("text-[1.25rem] font-extrabold", verdict.c)}>{verdict.t}</p>
                <div className="mt-4 grid grid-cols-3 gap-3">
                  <div>
                    <p className="text-[1.5rem] font-extrabold tabnum">{calc.need}</p>
                    <p className="text-[11.5px] font-bold text-sumi-500">шаардлагатай цаг</p>
                  </div>
                  <div>
                    <p className="text-[1.5rem] font-extrabold tabnum">{calc.have}</p>
                    <p className="text-[11.5px] font-bold text-sumi-500">таны боломжит цаг</p>
                  </div>
                  <div>
                    <p className="text-[1.5rem] font-extrabold tabnum">{calc.valid ? calc.recMin : "—"}</p>
                    <p className="text-[11.5px] font-bold text-sumi-500">санал болгох мин/өдөр</p>
                  </div>
                </div>
              </div>
            </div>
            <p className="px-6 py-3 text-[11.5px] text-sumi-500 sm:px-8">
              Тооцоо нь ханз хэрэглэдэггүй орны (Монгол г.м) суралцагчдад өргөн иш татагддаг ойролцоо цагийн дундаж дээр үндэслэсэн. Хувь хүнээс хамааран ±30% зөрнө.
            </p>
          </Card>

          <Card className="p-6">
            <h3 className="text-[1.05rem] font-extrabold">{p.target}-д зориулсан цагийн хуваарилалт</h3>
            <div className="mt-4 flex h-4 overflow-hidden rounded-full">
              {focus.map((f, i) => (
                <div key={f.label} style={{ width: `${f.pct}%` }} className={["bg-shu-500", "bg-ai-500", "bg-kin-500", "bg-matcha-500", "bg-murasaki-500"][i]} />
              ))}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
              {focus.map((f, i) => (
                <div key={f.label} className="flex items-start gap-2">
                  <i className={cn("mt-1 h-2.5 w-2.5 shrink-0 rounded-sm", ["bg-shu-500", "bg-ai-500", "bg-kin-500", "bg-matcha-500", "bg-murasaki-500"][i])} />
                  <div>
                    <p className="text-[12.5px] font-bold">{f.label}</p>
                    <p className="font-mono text-[11px] text-sumi-500 tabnum">
                      {f.pct}% · {Math.round((p.dailyGoal * f.pct) / 100)} мин
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-[1.05rem] font-extrabold">Гурван үе шат</h3>
            <ol className="mt-4 grid gap-3 sm:grid-cols-3">
              {phaseDates.map((ph, i) => (
                <li key={ph.n} className="relative rounded-xl border border-sumi-900/10 bg-white/60 p-4">
                  <span className="font-mincho text-[1.6rem] font-black text-shu-500">{ph.n}</span>
                  <p className="text-[14px] font-extrabold">
                    {i + 1}. {ph.t}
                  </p>
                  <p className="mt-0.5 font-mono text-[11px] text-sumi-500">
                    {fmtDate(ph.start)} → {fmtDate(ph.end)}
                  </p>
                  <p className="mt-2 text-[12.5px] leading-relaxed text-sumi-600">{ph.d}</p>
                </li>
              ))}
            </ol>
          </Card>

          <Card className="p-6">
            <h3 className="text-[1.05rem] font-extrabold">Долоо хоногийн загвар хуваарь</h3>
            <div className="mt-4 grid grid-cols-7 gap-1.5">
              {WEEK.map((w) => (
                <div key={w.d} className="rounded-xl border border-sumi-900/10 bg-white/60 p-2 text-center sm:p-3">
                  <p className="text-[11px] font-bold text-sumi-500">{w.d}</p>
                  <p className="mt-1 font-mincho text-[1.4rem] font-black text-sumi-800">{w.k}</p>
                  <p className="mt-1 hidden text-[10.5px] font-semibold leading-tight text-sumi-600 sm:block">{w.focus}</p>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[12px] text-sumi-500">Өдөр бүр эхний 5–10 минутыг SRS давталтад зарцуул — энэ нь бусад бүх зүйлийн суурь.</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
