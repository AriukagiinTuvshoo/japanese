import { useState } from "react";
import { LEVEL_META, type Level } from "../data/levels";
import { KANJI, kanjiByLevel, type KanjiItem } from "../data/kanji";
import { useStore } from "../lib/store";
import { focusLevel } from "../lib/progress";
import { isLearned, isMastered } from "../lib/srs";
import Flashcards, { type FlashItem } from "../components/Flashcards";
import { Button, Card, LevelTabs, PageHeader, Ruby, SpeakButton, levelTone } from "../components/ui";
import { cn } from "../utils/cn";

export default function Kanji() {
  const { state, today } = useStore();
  const [lv, setLv] = useState<Level>(() => focusLevel(state));
  const list = kanjiByLevel(lv);
  const [selId, setSelId] = useState<string>(list[0]?.id ?? "");
  const [session, setSession] = useState<FlashItem[] | null>(null);
  const sel = KANJI.find((k) => k.id === selId) ?? list[0];

  const now = Date.now();
  const due = KANJI.filter((k) => state.srs[k.id] && state.srs[k.id].due <= now);
  const fresh = list.filter((k) => !state.srs[k.id]);
  const learned = list.filter((k) => isLearned(state.srs[k.id])).length;
  const newLeft = Math.max(5, state.profile.newPerDay - today.newCards);

  const toItem = (k: KanjiItem, isNew: boolean): FlashItem => ({
    id: k.id,
    isNew,
    front: <span className="font-mincho text-[7rem] font-black leading-none text-sumi-900">{k.k}</span>,
    back: (
      <div className="space-y-3">
        <p className="text-[1.35rem] font-extrabold text-sumi-900">{k.mn}</p>
        <div className="flex flex-wrap justify-center gap-2 text-[13px]">
          <span className="rounded-lg bg-ai-50 px-2.5 py-1 font-jp font-bold text-ai-600">音 {k.on}</span>
          <span className="rounded-lg bg-shu-50 px-2.5 py-1 font-jp font-bold text-shu-600">訓 {k.kun}</span>
        </div>
        <div className="flex items-center justify-center gap-2">
          <Ruby text={`${k.ex}{${k.exR}}`} furigana className="text-[1.5rem] font-bold" />
          <span className="text-[13px] text-sumi-500">— {k.exMn}</span>
          <SpeakButton text={k.exR} size="sm" />
        </div>
      </div>
    ),
  });

  if (session) return <Flashcards items={session} title={`${lv} · Ханз`} onExit={() => setSession(null)} />;

  const t = levelTone(lv);

  return (
    <div>
      <PageHeader
        kanji="漢"
        eyebrow="Суралцах · Ханз"
        title="Ханз — утга, уншлага, жишээ үг"
        sub="Ханз бүрийг ганцаар нь биш, жишээ үгтэй нь цээжил. 音 (он) — хятад гаралтай уншлага, 訓 (кун) — япон уншлага."
        right={
          <>
            <Button onClick={() => setSession(due.slice(0, 50).map((k) => toItem(k, false)))} disabled={due.length === 0}>
              Давтах · {due.length}
            </Button>
            <Button variant="ink" onClick={() => setSession(fresh.slice(0, newLeft).map((k) => toItem(k, true)))} disabled={fresh.length === 0}>
              Шинэ ханз · {Math.min(fresh.length, newLeft)}
            </Button>
          </>
        }
      />

      <LevelTabs
        value={lv}
        onChange={(l) => {
          setLv(l);
          setSelId(kanjiByLevel(l)[0]?.id ?? "");
        }}
        meta={(l) => `${kanjiByLevel(l).filter((k) => isLearned(state.srs[k.id])).length}/${kanjiByLevel(l).length}`}
      />

      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_360px]">
        <Card className="p-4 sm:p-5">
          <div className="mb-4 flex items-baseline justify-between">
            <p className="text-[13px] font-bold text-sumi-600">
              {lv}: <span className="tabnum">{learned}/{list.length}</span> сурсан
            </p>
            <p className="text-[11.5px] text-sumi-500">JLPT {lv} хүртэл ~{LEVEL_META[lv].kanji.toLocaleString()} ханз</p>
          </div>
          <div className="grid grid-cols-5 gap-2 sm:grid-cols-8 xl:grid-cols-10">
            {list.map((k) => {
              const c = state.srs[k.id];
              const on = sel?.id === k.id;
              return (
                <button
                  key={k.id}
                  onClick={() => setSelId(k.id)}
                  className={cn(
                    "relative grid aspect-square place-items-center rounded-xl border font-mincho text-[clamp(1.4rem,3.6vw,1.9rem)] font-bold transition-all duration-200 hover:-translate-y-0.5",
                    on ? "border-shu-500 bg-shu-500 text-white shadow-[0_10px_20px_-12px_rgba(204,70,48,0.9)]" : "border-sumi-900/10 bg-white/70 text-sumi-900 hover:border-sumi-900/25",
                  )}
                >
                  {k.k}
                  {c && (
                    <i
                      className={cn(
                        "absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full",
                        isMastered(c) ? "bg-matcha-500" : "bg-kin-400",
                        on && "ring-2 ring-white",
                      )}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </Card>

        {sel && (
          <Card className="sticky top-6 self-start overflow-hidden">
            <div className="genko relative grid place-items-center bg-white py-8">
              <div className="pointer-events-none absolute inset-6 border border-dashed border-shu-100" />
              <div className="pointer-events-none absolute left-1/2 top-6 bottom-6 w-px border-l border-dashed border-shu-100" />
              <div className="pointer-events-none absolute left-6 right-6 top-1/2 h-px border-t border-dashed border-shu-100" />
              <span key={sel.id} className="relative animate-pop font-mincho text-[8.5rem] font-black leading-none text-sumi-900">
                {sel.k}
              </span>
              <span className={cn("absolute left-4 top-4 rounded-md px-2 py-0.5 font-mono text-[11px] font-bold", t.solid)}>{sel.level}</span>
            </div>
            <div className="space-y-4 p-5">
              <p className="text-[1.4rem] font-extrabold">{sel.mn}</p>
              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-xl bg-ai-50 p-3">
                  <p className="font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-ai-500">音 Он</p>
                  <p className="mt-1 font-jp text-[15px] font-bold text-sumi-900">{sel.on}</p>
                </div>
                <div className="rounded-xl bg-shu-50 p-3">
                  <p className="font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-shu-600">訓 Кун</p>
                  <p className="mt-1 font-jp text-[15px] font-bold text-sumi-900">{sel.kun}</p>
                </div>
              </div>
              <div className="rounded-xl border border-sumi-900/10 bg-white/70 p-4">
                <p className="font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-sumi-500">Жишээ үг</p>
                <div className="mt-2 flex items-center gap-3">
                  <Ruby text={`${sel.ex}{${sel.exR}}`} furigana className="text-[1.7rem] font-bold" />
                  <SpeakButton text={sel.exR} size="sm" />
                </div>
                <p className="mt-1 text-[13.5px] font-semibold text-sumi-600">{sel.exMn}</p>
              </div>
              <Button variant="outline" className="w-full" onClick={() => setSession([toItem(sel, !state.srs[sel.id])])}>
                Энэ ханзыг давтах
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
