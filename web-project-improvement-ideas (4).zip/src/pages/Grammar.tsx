import { useMemo, useState } from "react";
import { LEVEL_META, type Level } from "../data/levels";
import { GRAMMAR, grammarByLevel } from "../data/grammar";
import { useStore } from "../lib/store";
import { focusLevel } from "../lib/progress";
import { qGrammar, type Question } from "../lib/exam";
import { blank, plain, shuffle, target } from "../lib/text";
import Quiz from "../components/Quiz";
import { Button, Card, LevelTabs, OptionButton, PageHeader, Ruby, SpeakButton, levelTone } from "../components/ui";
import { cn } from "../utils/cn";

export default function Grammar() {
  const { state, actions } = useStore();
  const [lv, setLv] = useState<Level>(() => focusLevel(state));
  const list = grammarByLevel(lv);
  const [selId, setSelId] = useState(() => list.find((g) => !state.grammarDone.includes(g.id))?.id ?? list[0]?.id);
  const [showMn, setShowMn] = useState(true);
  const [quiz, setQuiz] = useState<Question[] | null>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const sel = GRAMMAR.find((g) => g.id === selId) ?? list[0];

  const opts = useMemo(() => (sel ? shuffle([target(sel.q.s), ...sel.q.d]) : []), [sel]);
  const ans = sel ? target(sel.q.s) : "";

  if (quiz)
    return (
      <Quiz
        questions={quiz}
        title={`${lv} · Дүрмийн сорил`}
        onExit={() => setQuiz(null)}
        finishLabel="Зөвийг тэмдэглэх"
        onFinish={({ answers }) => {
          quiz.forEach((qq, k) => {
            if (answers[k] === qq.answer) actions.toggleGrammar(qq.id.replace(/^gq-/, ""), true);
          });
          setQuiz(null);
        }}
      />
    );

  const done = list.filter((g) => state.grammarDone.includes(g.id)).length;
  const t = levelTone(lv);
  const idx = sel ? list.findIndex((g) => g.id === sel.id) : -1;

  const choose = (o: string, k: number) => {
    if (picked !== null || !sel) return;
    setPicked(k);
    if (o === ans) {
      actions.toggleGrammar(sel.id, true);
      actions.addXP(5);
    } else {
      actions.addMistakes([
        { id: `gq-${sel.id}`, kind: "Дүрмийн хэлбэр", level: sel.level, prompt: blank(sel.q.s), answer: ans, given: o, note: `${sel.p} — ${sel.mn}` },
      ]);
    }
  };

  const goTo = (id: string) => {
    setSelId(id);
    setPicked(null);
  };

  return (
    <div>
      <PageHeader
        kanji="文"
        eyebrow="Суралцах · Дүрэм"
        title="Дүрэм — монгол тайлбартай"
        sub="Хэлбэр бүрийг: утга → холболт → анхаарах зүйл → жишээ → өөрийгөө шалгах гэсэн дарааллаар сур. Шалгалтыг зөв хариулсан дүрэм «сурсан» гэж тэмдэглэгдэнэ."
        right={
          <Button variant="ink" onClick={() => setQuiz(qGrammar(lv, list.length))}>
            {lv} бүх дүрмийн сорил
          </Button>
        }
      />

      <LevelTabs
        value={lv}
        onChange={(l) => {
          setLv(l);
          const gl = grammarByLevel(l);
          goTo(gl.find((g) => !state.grammarDone.includes(g.id))?.id ?? gl[0]?.id);
        }}
        meta={(l) => `${grammarByLevel(l).filter((g) => state.grammarDone.includes(g.id)).length}/${grammarByLevel(l).length}`}
      />

      <div className="mt-5 grid gap-5 lg:grid-cols-[320px_1fr]">
        <Card className="self-start p-3 lg:sticky lg:top-6">
          <div className="flex items-center justify-between px-2 pb-3 pt-1">
            <p className="text-[12.5px] font-bold text-sumi-600">
              {LEVEL_META[lv].name} · <span className="tabnum">{done}/{list.length}</span>
            </p>
            <div className="h-1.5 w-24 overflow-hidden rounded-full bg-sumi-900/[0.07]">
              <div className={cn("h-full rounded-full", t.bar)} style={{ width: `${(done / Math.max(1, list.length)) * 100}%` }} />
            </div>
          </div>
          <ul className="no-scrollbar max-h-[62vh] space-y-0.5 overflow-y-auto">
            {list.map((g, i) => {
              const isDone = state.grammarDone.includes(g.id);
              const on = sel?.id === g.id;
              return (
                <li key={g.id}>
                  <button
                    onClick={() => goTo(g.id)}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-all",
                      on ? "bg-sumi-900 text-washi-50" : "hover:bg-sumi-900/5",
                    )}
                  >
                    <span
                      className={cn(
                        "grid h-6 w-6 shrink-0 place-items-center rounded-md font-mono text-[10.5px] font-bold",
                        isDone ? "bg-matcha-500 text-white" : on ? "bg-white/15 text-washi-200" : "bg-washi-200 text-sumi-500",
                      )}
                    >
                      {isDone ? "✓" : i + 1}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-jp text-[14px] font-bold">{g.p}</span>
                      <span className={cn("block truncate text-[11.5px]", on ? "text-washi-400" : "text-sumi-500")}>{g.mn}</span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </Card>

        {sel && (
          <div key={sel.id} className="animate-rise space-y-5">
            <Card className="relative overflow-hidden p-6 sm:p-8">
              <div className="seigaiha pointer-events-none absolute -right-8 top-0 h-full w-1/2 text-shu-500/[0.05]" />
              <div className="relative">
                <div className="flex items-center gap-2">
                  <span className={cn("rounded-md px-2 py-0.5 font-mono text-[11px] font-bold", t.solid)}>{sel.level}</span>
                  <span className="font-mono text-[11px] font-bold text-sumi-400">#{idx + 1}</span>
                  {state.grammarDone.includes(sel.id) && <span className="rounded-md bg-matcha-50 px-2 py-0.5 text-[11px] font-bold text-matcha-600">✓ Сурсан</span>}
                </div>
                <h2 className="mt-4 font-jp text-[clamp(2rem,5vw,2.8rem)] font-black leading-tight text-sumi-900">{sel.p}</h2>
                <p className="mt-2 text-[1.15rem] font-extrabold text-shu-600">{sel.mn}</p>

                <div className="mt-6 grid gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-sumi-900/10 bg-white/70 p-4">
                    <p className="font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-sumi-500">接続 · Холболт</p>
                    <p className="mt-1.5 font-jp text-[14px] font-bold leading-relaxed text-sumi-800">{sel.form}</p>
                  </div>
                  <div className="rounded-xl border border-kin-400/40 bg-kin-50 p-4">
                    <p className="font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-kin-600">注意 · Анхаар</p>
                    <p className="mt-1.5 font-jp text-[13.5px] leading-relaxed text-sumi-700">{sel.note}</p>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-5 sm:p-6">
              <div className="flex items-center justify-between">
                <h3 className="text-[1rem] font-extrabold">例文 · Жишээ өгүүлбэр</h3>
                <button onClick={() => setShowMn((x) => !x)} className="text-[12px] font-bold text-ai-500 hover:underline">
                  {showMn ? "Орчуулга нуух" : "Орчуулга харах"}
                </button>
              </div>
              <ul className="mt-4 space-y-3">
                {sel.ex.map(([jp, mn], k) => (
                  <li key={k} className="flex items-start gap-3 rounded-xl border border-sumi-900/[0.07] bg-white/60 p-4">
                    <SpeakButton text={plain(jp)} size="sm" className="mt-1" />
                    <div className="min-w-0 flex-1">
                      <p className="text-[1.15rem] leading-[2.1] text-sumi-900">
                        <Ruby text={jp} />
                      </p>
                      {showMn && <p className="text-[13.5px] font-semibold text-sumi-500">{mn}</p>}
                    </div>
                  </li>
                ))}
              </ul>
            </Card>

            <Card className="p-5 sm:p-6">
              <h3 className="text-[1rem] font-extrabold">確認 · Өөрийгөө шалга</h3>
              <p className="mt-1 text-[12.5px] text-sumi-500">Хоосон зайд тохирох хэлбэрийг сонго.</p>
              <p className="mt-4 rounded-xl bg-white/70 px-4 py-4 text-center text-[1.2rem] leading-[2.1]">
                <Ruby text={picked === null ? blank(sel.q.s) : sel.q.s} />
              </p>
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                {opts.map((o, k) => (
                  <OptionButton
                    key={o}
                    idx={k}
                    disabled={picked !== null}
                    onClick={() => choose(o, k)}
                    state={picked === null ? "idle" : o === ans ? "correct" : k === picked ? "wrong" : "dim"}
                  >
                    <span className="font-jp">{o}</span>
                  </OptionButton>
                ))}
              </div>
              {picked !== null && (
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                  <p className={cn("text-[13.5px] font-extrabold", opts[picked] === ans ? "text-matcha-600" : "text-shu-600")}>
                    {opts[picked] === ans ? "✓ Зөв! Дүрэм «сурсан» гэж тэмдэглэгдлээ. +5 XP" : "✕ Дахин уншаад оролдоорой — алдааны дэвтэрт нэмэгдлээ."}
                  </p>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => setPicked(null)}>
                      Дахин
                    </Button>
                    {idx < list.length - 1 && (
                      <Button size="sm" onClick={() => goTo(list[idx + 1].id)}>
                        Дараагийн дүрэм →
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
