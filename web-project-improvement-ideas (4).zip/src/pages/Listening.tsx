import { useEffect, useMemo, useRef, useState } from "react";
import { toHiragana } from "wanakana";
import type { Level } from "../data/levels";
import { VOCAB, vocabByLevel } from "../data/vocab";
import { toHiraganaChars } from "../data/kana";
import { useStore } from "../lib/store";
import { focusLevel } from "../lib/progress";
import { qListening, type Question } from "../lib/exam";
import { hasJapaneseVoice, canSpeak, speak } from "../lib/speech";
import { sample, shuffle } from "../lib/text";
import Quiz from "../components/Quiz";
import { Bar, Button, Card, LevelTabs, PageHeader } from "../components/ui";
import { cn } from "../utils/cn";

type Mode = "word" | "sentence" | "dictation";

function wordQuestions(lv: Level, n: number): Question[] {
  const pool = vocabByLevel(lv);
  return sample(pool, n).map((v) => {
    const distract = sample(VOCAB.filter((x) => x.id !== v.id && x.mn !== v.mn), 3).map((x) => x.mn);
    const options = shuffle([v.mn, ...distract]);
    return {
      id: `lw-${v.id}`,
      section: "listening",
      kind: "聴解",
      kindMn: "Үг сонсох",
      level: lv,
      prompt: "",
      speak: v.r,
      options,
      answer: options.indexOf(v.mn),
      explain: `${v.w}（${v.r}）— ${v.mn}`,
    };
  });
}

export default function Listening() {
  const { state, actions } = useStore();
  const [lv, setLv] = useState<Level>(() => focusLevel(state));
  const [run, setRun] = useState<{ mode: Mode; qs: Question[] } | null>(null);
  const voiceOk = hasJapaneseVoice();

  if (run && run.mode !== "dictation")
    return <Quiz questions={run.qs} title={run.mode === "word" ? `${lv} · Үг сонсох` : `${lv} · Өгүүлбэр сонсох`} onExit={() => setRun(null)} />;
  if (run && run.mode === "dictation") return <Dictation lv={lv} onExit={(xp) => { if (xp) actions.addXP(xp); setRun(null); }} />;

  const modes: { id: Mode; k: string; t: string; d: string; start: () => void }[] = [
    { id: "word", k: "単", t: "Үг сонсох", d: "Үгийг сонсоод монгол утгыг сонго. 10 асуулт.", start: () => setRun({ mode: "word", qs: wordQuestions(lv, 10) }) },
    { id: "sentence", k: "文", t: "Өгүүлбэр сонсох", d: "Бүтэн өгүүлбэрийн утгыг ол — JLPT 聴解-ийн суурь. 8 асуулт.", start: () => setRun({ mode: "sentence", qs: qListening(lv, 8) }) },
    { id: "dictation", k: "書", t: "Диктант", d: "Сонссон үгээ кана-гаар бич. Romaji бичвэл автоматаар хирагана болно.", start: () => setRun({ mode: "dictation", qs: [] }) },
  ];

  return (
    <div>
      <PageHeader
        kanji="聴"
        eyebrow="Чадвар · Сонсгол"
        title="Сонсгол — 聴解"
        sub={`Японоор бодож сонсох дадлыг өдөр бүр 3–5 минут. Хурдыг тохиргооноос өөрчилнө (одоо ${state.profile.rate.toFixed(2)}×).`}
      />

      {(!canSpeak() || !voiceOk) && (
        <Card className="mb-5 border-kin-400/50 bg-kin-50 p-4">
          <p className="text-[13.5px] font-bold text-kin-600">⚠ Япон дуу хоолой олдсонгүй</p>
          <p className="mt-1 text-[12.5px] text-sumi-600">
            Хөтөч/үйлдлийн системдээ япон хэлний дуу хоолой (Text-to-Speech) суулгавал дуудлага илүү зөв болно. Chrome, Edge, Safari дээр ихэвчлэн бэлэн байдаг.
          </p>
        </Card>
      )}

      <LevelTabs value={lv} onChange={setLv} />

      <div className="mt-5 grid gap-4 md:grid-cols-3">
        {modes.map((m) => (
          <button key={m.id} onClick={m.start} className="group text-left">
            <Card className="relative h-full overflow-hidden p-6 transition-all duration-300 group-hover:-translate-y-1 group-hover:border-shu-400/60">
              <div className="seigaiha pointer-events-none absolute inset-x-0 bottom-0 h-16 text-shu-500/[0.06]" />
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-sumi-900 font-mincho text-[1.7rem] font-black text-washi-50 transition-colors group-hover:bg-shu-500">
                {m.k}
              </span>
              <h3 className="mt-5 text-[1.15rem] font-extrabold">{m.t}</h3>
              <p className="mt-1.5 text-[13px] leading-relaxed text-sumi-600">{m.d}</p>
              <p className="relative mt-5 text-[12.5px] font-extrabold text-shu-600">Эхлэх →</p>
            </Card>
          </button>
        ))}
      </div>

      <Card className="mt-6 p-6">
        <h3 className="text-[1.05rem] font-extrabold">JLPT сонсголын 4 зөвлөгөө</h3>
        <ol className="mt-4 grid gap-4 sm:grid-cols-2">
          {[
            ["Асуултыг урьдчилж унш", "Сонсохоос өмнө хэн, хаана, юу хийх гэж байгааг таамагла."],
            ["Эхний санаанд бүү итгэ", "JLPT-д яриаг дунд нь «でも…» гэж эргүүлдэг. Сүүлийн шийдвэрийг сонс."],
            ["Тэмдэглэл хөтөл", "Тоо, цаг, газрын нэрийг хурдан тэмдэглэ. Бүтэн өгүүлбэр бичих хэрэггүй."],
            ["Shadowing", "Сонссон өгүүлбэрээ 0.5 секунд хоцроод чангаар давт. Өдөр бүр 5 мин."],
          ].map(([t, d], i) => (
            <li key={t} className="flex gap-3">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-shu-50 font-mono text-[12px] font-bold text-shu-600">{i + 1}</span>
              <div>
                <p className="text-[13.5px] font-extrabold">{t}</p>
                <p className="mt-0.5 text-[12.5px] leading-relaxed text-sumi-600">{d}</p>
              </div>
            </li>
          ))}
        </ol>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
const norm = (s: string) => toHiraganaChars(toHiragana(s.trim().toLowerCase(), { passRomaji: false })).replace(/\s+/g, "");

function Dictation({ lv, onExit }: { lv: Level; onExit: (xp: number) => void }) {
  const { state, actions } = useStore();
  const items = useMemo(() => sample(vocabByLevel(lv), 10), [lv]);
  const [i, setI] = useState(0);
  const [val, setVal] = useState("");
  const [res, setRes] = useState<null | boolean>(null);
  const [score, setScore] = useState(0);
  const ref = useRef<HTMLInputElement | null>(null);
  const cur = items[i];

  useEffect(() => {
    if (!cur) return;
    const t = window.setTimeout(() => speak(cur.r, state.profile.rate), 250);
    ref.current?.focus();
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i]);

  if (!cur)
    return (
      <Card className="mx-auto max-w-xl animate-pop p-8 text-center">
        <p className="font-mincho text-[3.4rem] font-black text-matcha-500">{score >= 8 ? "優" : score >= 5 ? "良" : "可"}</p>
        <h2 className="mt-2 text-[1.6rem] font-extrabold tabnum">{score}/{items.length}</h2>
        <Button className="mt-6 w-full" onClick={() => onExit(score * 2)}>
          Дуусгах +{score * 2} XP
        </Button>
      </Card>
    );

  const preview = val ? toHiragana(val, { IMEMode: true }) : "";

  const submit = () => {
    if (res !== null) {
      setI((x) => x + 1);
      setVal("");
      setRes(null);
      return;
    }
    const ok = norm(val) === norm(cur.r);
    setRes(ok);
    if (ok) setScore((s) => s + 1);
    else actions.addMistakes([{ id: `dc-${cur.id}`, kind: "Диктант", level: lv, prompt: `🔊 ${cur.r}`, answer: cur.r, given: val, note: `${cur.w} — ${cur.mn}` }]);
  };

  return (
    <div className="mx-auto max-w-xl">
      <div className="mb-4 flex items-center gap-3">
        <button onClick={() => onExit(0)} className="grid h-9 w-9 place-items-center rounded-xl border border-sumi-900/10 bg-white/70" aria-label="Гарах">
          ✕
        </button>
        <div className="flex-1">
          <div className="mb-1.5 flex justify-between text-[12px] font-bold text-sumi-500">
            <span>{lv} · Диктант</span>
            <span className="tabnum">{i + 1}/{items.length}</span>
          </div>
          <Bar value={i / items.length} />
        </div>
      </div>
      <Card className="p-8 text-center">
        <button
          onClick={() => speak(cur.r, state.profile.rate)}
          className="mx-auto grid h-24 w-24 place-items-center rounded-full bg-shu-500 text-white shadow-[0_14px_30px_-14px_rgba(204,70,48,0.9)] transition-transform hover:scale-105 active:scale-95"
          aria-label="Сонсох"
        >
          <svg viewBox="0 0 24 24" className="h-10 w-10" fill="currentColor">
            <path d="M11 5 6 9H3v6h3l5 4V5Z" />
            <path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
        <button onClick={() => speak(cur.r, Math.max(0.5, state.profile.rate - 0.3))} className="mt-3 text-[12px] font-bold text-sumi-500 hover:text-shu-600">
          🐢 Удаан сонсох
        </button>
        <form
          className="mt-6"
          onSubmit={(e) => {
            e.preventDefault();
            if (val.trim() || res !== null) submit();
          }}
        >
          <input
            ref={ref}
            value={val}
            onChange={(e) => setVal(e.target.value)}
            disabled={res !== null}
            placeholder="がっこう эсвэл gakkou"
            autoCapitalize="off"
            autoCorrect="off"
            className={cn(
              "h-14 w-full rounded-xl border-2 bg-white px-5 text-center font-jp text-[20px] font-bold outline-none transition-all",
              res === null ? "border-sumi-900/15 focus:border-ai-500" : res ? "border-matcha-500 bg-matcha-50" : "shake border-shu-500 bg-shu-50",
            )}
          />
          {res === null && preview && preview !== val && <p className="mt-2 font-jp text-[15px] font-bold text-ai-500">→ {preview}</p>}
          {res !== null && (
            <p className="mt-3 text-[14px]">
              <span className="font-jp text-[1.3rem] font-bold">{cur.w}</span>
              <span className="ml-2 font-jp text-shu-600">（{cur.r}）</span>
              <span className="ml-2 text-sumi-600">— {cur.mn}</span>
            </p>
          )}
          <Button type="submit" className="mt-5 w-full" variant={res === null ? "primary" : "ink"}>
            {res === null ? "Шалгах" : "Дараах →"}
          </Button>
        </form>
      </Card>
    </div>
  );
}
