import { useEffect, useMemo, useRef, useState } from "react";
import { ALL_KANA, KANA_ROWS, KANA_TIPS, type KanaGroup, type KanaItem } from "../data/kana";
import { useStore } from "../lib/store";
import { speak } from "../lib/speech";
import { sample, shuffle } from "../lib/text";
import { Bar, Button, Card, OptionButton, PageHeader, Segmented } from "../components/ui";
import { cn } from "../utils/cn";

type Script = "h" | "k";

export default function Kana() {
  const { state } = useStore();
  const [script, setScript] = useState<Script>("h");
  const [group, setGroup] = useState<KanaGroup>("basic");
  const [quiz, setQuiz] = useState<{ rows: string[]; mode: "pick" | "type" } | null>(null);
  const [rows, setRows] = useState<string[]>(["a", "k", "s"]);
  const [mode, setMode] = useState<"pick" | "type">("pick");

  if (quiz) return <KanaQuiz script={script} rows={quiz.rows} mode={quiz.mode} onExit={() => setQuiz(null)} />;

  const shownRows = KANA_ROWS.filter((r) => r.group === group);
  const cols = group === "yoon" ? 3 : 5;

  return (
    <div>
      <PageHeader
        kanji="あ"
        eyebrow="Суурь · 01"
        title="Хирагана ба Катакана"
        sub="Япон хэлний бүх зүйл эндээс эхэлнэ. 46 үндсэн үсэг, дуудлагын өөрчлөлт (゛゜), нийлмэл авиа (ゃゅょ). Үсэг дээр дарж сонсоорой."
        right={
          <Segmented
            value={script}
            onChange={setScript}
            options={[
              { id: "h", label: "ひらがな" },
              { id: "k", label: "カタカナ" },
            ]}
          />
        }
      />

      <div className="grid gap-6 xl:grid-cols-[1fr_340px]">
        <Card className="p-4 sm:p-6">
          <div className="mb-5 flex flex-wrap items-center gap-2">
            {(
              [
                ["basic", "Үндсэн 46"],
                ["dakuten", "゛゜ Дакутэн 25"],
                ["yoon", "ゃゅょ Ёон 33"],
              ] as [KanaGroup, string][]
            ).map(([g, l]) => (
              <button
                key={g}
                onClick={() => setGroup(g)}
                className={cn(
                  "rounded-xl border px-3.5 py-2 text-[12.5px] font-bold transition-all",
                  group === g ? "border-sumi-900 bg-sumi-900 text-washi-50" : "border-sumi-900/10 bg-white/60 text-sumi-600 hover:border-sumi-900/25",
                )}
              >
                {l}
              </button>
            ))}
          </div>

          <div className="space-y-2">
            <div className={cn("grid gap-2 pl-10", cols === 5 ? "grid-cols-5" : "grid-cols-3")}>
              {(cols === 5 ? ["a", "i", "u", "e", "o"] : ["ya", "yu", "yo"]).map((c) => (
                <span key={c} className="text-center font-mono text-[10.5px] font-bold uppercase tracking-wider text-sumi-400">
                  {c}
                </span>
              ))}
            </div>
            {shownRows.map((row) => (
              <div key={row.id} className="flex items-center gap-2">
                <span className="w-8 shrink-0 text-center font-mono text-[11px] font-bold text-sumi-400">{row.id === "a" ? "—" : row.id === "nn" ? "n" : row.id}</span>
                <div className={cn("grid flex-1 gap-2", cols === 5 ? "grid-cols-5" : "grid-cols-3")}>
                  {row.cells.map((c, i) =>
                    c ? (
                      <button
                        key={i}
                        onClick={() => speak(c[0], state.profile.rate)}
                        className="group relative flex aspect-square flex-col items-center justify-center rounded-xl border border-sumi-900/10 bg-white/70 transition-all duration-200 hover:-translate-y-0.5 hover:border-shu-400 hover:bg-white hover:shadow-[0_10px_20px_-14px_rgba(204,70,48,0.8)] active:scale-95 sm:aspect-[1/1.05]"
                      >
                        <span className={cn("font-jp font-bold leading-none text-sumi-900 group-hover:text-shu-600", group === "yoon" ? "text-[clamp(1.4rem,4vw,2.1rem)]" : "text-[clamp(1.5rem,4.4vw,2.4rem)]")}>
                          {script === "h" ? c[0] : ALL_KANA.find((k) => k.h === c[0])?.k}
                        </span>
                        <span className="mt-1.5 font-mono text-[10.5px] font-semibold text-sumi-500">{c[1]}</span>
                      </button>
                    ) : (
                      <span key={i} />
                    ),
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-6">
          <Card className="p-5">
            <h2 className="text-[1.05rem] font-extrabold">Хурдны сорил</h2>
            <p className="mt-1 text-[12.5px] text-sumi-500">Мөрөө сонгоод 20 асуулттай сорил өг. Хамгийн сайн: <b className="text-sumi-800">{state.kanaBest}%</b></p>
            <div className="mt-4 flex flex-wrap gap-1.5">
              {KANA_ROWS.map((r) => {
                const on = rows.includes(r.id);
                return (
                  <button
                    key={r.id}
                    onClick={() => setRows((x) => (on ? x.filter((y) => y !== r.id) : [...x, r.id]))}
                    className={cn(
                      "min-w-10 rounded-lg border px-2 py-1.5 font-jp text-[14px] font-bold transition-all",
                      on ? "border-shu-500 bg-shu-500 text-white" : "border-sumi-900/10 bg-white/60 text-sumi-600 hover:border-sumi-900/25",
                    )}
                  >
                    {script === "h" ? r.label : ALL_KANA.find((k) => k.h === r.label)?.k ?? r.label}
                  </button>
                );
              })}
            </div>
            <div className="mt-3 flex gap-2 text-[11.5px] font-bold">
              <button onClick={() => setRows(KANA_ROWS.filter((r) => r.group === "basic").map((r) => r.id))} className="text-ai-500 hover:underline">
                Үндсэн бүгд
              </button>
              <button onClick={() => setRows(KANA_ROWS.map((r) => r.id))} className="text-ai-500 hover:underline">
                Бүгд
              </button>
              <button onClick={() => setRows([])} className="text-sumi-500 hover:underline">
                Цэвэрлэх
              </button>
            </div>
            <div className="mt-4">
              <Segmented
                value={mode}
                onChange={setMode}
                options={[
                  { id: "pick", label: "Сонгох" },
                  { id: "type", label: "Бичих (romaji)" },
                ]}
              />
            </div>
            <Button className="mt-4 w-full" disabled={rows.length === 0} onClick={() => setQuiz({ rows, mode })}>
              Сорил эхлүүлэх →
            </Button>
          </Card>

          <Card className="p-5">
            <h2 className="text-[1.05rem] font-extrabold">Хэрхэн цээжлэх вэ</h2>
            <ol className="mt-4 space-y-3.5">
              {KANA_TIPS.map((t, i) => (
                <li key={t.t} className="flex gap-3">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-washi-200 font-mono text-[11px] font-bold text-sumi-600">{i + 1}</span>
                  <div>
                    <p className="text-[13.5px] font-extrabold">{t.t}</p>
                    <p className="mt-0.5 text-[12.5px] leading-relaxed text-sumi-600">{t.d}</p>
                  </div>
                </li>
              ))}
            </ol>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
function KanaQuiz({ script, rows, mode, onExit }: { script: Script; rows: string[]; mode: "pick" | "type"; onExit: () => void }) {
  const { state, actions } = useStore();
  const pool = useMemo(() => ALL_KANA.filter((k) => rows.includes(k.row)), [rows]);
  const qs = useMemo<KanaItem[]>(() => {
    const out: KanaItem[] = [];
    while (out.length < 20) out.push(...shuffle(pool));
    return out.slice(0, 20);
  }, [pool]);
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [typed, setTyped] = useState("");
  const [score, setScore] = useState(0);
  const [missed, setMissed] = useState<KanaItem[]>([]);
  const startAt = useRef(Date.now());
  const inputRef = useRef<HTMLInputElement | null>(null);

  const q = qs[i];
  const options = useMemo(() => {
    if (!q) return [];
    const romajiPool = Array.from(new Set(ALL_KANA.map((k) => k.r))).filter((r) => r !== q.r);
    const near = pool.map((p) => p.r).filter((r) => r !== q.r);
    return shuffle([q.r, ...sample(Array.from(new Set([...near, ...sample(romajiPool, 4)])), 3)]);
  }, [q, pool]);

  useEffect(() => {
    if (mode === "type") inputRef.current?.focus();
  }, [i, mode]);

  const answer = (r: string) => {
    if (picked) return;
    setPicked(r);
    const ok = r.trim().toLowerCase() === q.r;
    if (ok) setScore((s) => s + 1);
    else setMissed((m) => [...m, q]);
    speak(q.h, state.profile.rate);
    window.setTimeout(
      () => {
        setPicked(null);
        setTyped("");
        setI((x) => x + 1);
      },
      ok ? 550 : 1300,
    );
  };

  const finished = !q;
  useEffect(() => {
    if (finished) actions.setKanaBest(Math.round((score / qs.length) * 100));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [finished]);

  if (!q) {
    const pct = Math.round((score / qs.length) * 100);
    const secs = ((Date.now() - startAt.current) / 1000 / qs.length).toFixed(1);
    return (
      <Card className="mx-auto max-w-xl animate-pop p-8 text-center">
        <p className={cn("font-mincho text-[3.6rem] font-black leading-none", pct >= 90 ? "text-matcha-500" : pct >= 60 ? "text-kin-500" : "text-shu-500")}>
          {pct >= 90 ? "優" : pct >= 60 ? "良" : "可"}
        </p>
        <h2 className="mt-3 text-[1.6rem] font-extrabold tabnum">
          {score}/{qs.length} · {pct}%
        </h2>
        <p className="mt-1 text-[13px] text-sumi-500">Нэг үсэгт дунджаар {secs} сек</p>
        {missed.length > 0 && (
          <div className="mt-6">
            <p className="text-[12.5px] font-bold text-sumi-600">Давтах үсгүүд</p>
            <div className="mt-2 flex flex-wrap justify-center gap-2">
              {Array.from(new Map(missed.map((m) => [m.h, m])).values()).map((m) => (
                <button key={m.h} onClick={() => speak(m.h)} className="rounded-xl border border-shu-400/50 bg-shu-50 px-3 py-2">
                  <span className="font-jp text-[1.4rem] font-bold">{script === "h" ? m.h : m.k}</span>
                  <span className="ml-2 font-mono text-[11px] text-shu-600">{m.r}</span>
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="mt-7 grid grid-cols-2 gap-2">
          <Button variant="outline" onClick={onExit}>
            Хүснэгт рүү
          </Button>
          <Button
            onClick={() => {
              actions.addXP(score);
              onExit();
            }}
          >
            Дуусгах +{score} XP
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <div className="mx-auto max-w-xl">
      <div className="mb-4 flex items-center gap-3">
        <button onClick={onExit} className="grid h-9 w-9 place-items-center rounded-xl border border-sumi-900/10 bg-white/70" aria-label="Гарах">
          ✕
        </button>
        <div className="flex-1">
          <div className="mb-1.5 flex justify-between text-[12px] font-bold text-sumi-500">
            <span>{script === "h" ? "Хирагана" : "Катакана"} сорил</span>
            <span className="tabnum">
              {i + 1}/{qs.length} · ✓{score}
            </span>
          </div>
          <Bar value={i / qs.length} />
        </div>
      </div>

      <Card className="relative overflow-hidden">
        <div className="seigaiha pointer-events-none absolute inset-x-0 bottom-0 h-20 text-shu-500/[0.06]" />
        <div key={i} className="flip-in grid place-items-center py-14">
          <span className="font-jp text-[7rem] font-bold leading-none text-sumi-900">{script === "h" ? q.h : q.k}</span>
        </div>
      </Card>

      {mode === "pick" ? (
        <div className="mt-4 grid grid-cols-2 gap-2">
          {options.map((o, k) => (
            <OptionButton
              key={o}
              idx={k}
              disabled={!!picked}
              onClick={() => answer(o)}
              state={!picked ? "idle" : o === q.r ? "correct" : o === picked ? "wrong" : "dim"}
            >
              <span className="font-mono text-[17px]">{o}</span>
            </OptionButton>
          ))}
        </div>
      ) : (
        <form
          className="mt-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (typed.trim()) answer(typed);
          }}
        >
          <input
            ref={inputRef}
            value={typed}
            onChange={(e) => setTyped(e.target.value)}
            disabled={!!picked}
            placeholder="romaji бичээд Enter"
            autoCapitalize="off"
            autoCorrect="off"
            className={cn(
              "h-14 w-full rounded-xl border-2 bg-white px-5 text-center font-mono text-[20px] font-semibold outline-none transition-all",
              !picked
                ? "border-sumi-900/15 focus:border-ai-500"
                : picked.trim().toLowerCase() === q.r
                  ? "border-matcha-500 bg-matcha-50"
                  : "shake border-shu-500 bg-shu-50",
            )}
          />
          {picked && picked.trim().toLowerCase() !== q.r && (
            <p className="mt-2 text-center text-[13px] font-bold text-shu-600">
              Зөв хариулт: <span className="font-mono">{q.r}</span>
            </p>
          )}
        </form>
      )}
    </div>
  );
}
