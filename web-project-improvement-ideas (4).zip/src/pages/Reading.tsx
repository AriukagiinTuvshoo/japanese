import { useMemo, useState } from "react";
import { LEVELS, LEVEL_META } from "../data/levels";
import { PASSAGES, type Passage } from "../data/reading";
import { useStore } from "../lib/store";
import { speak, stopSpeaking } from "../lib/speech";
import { plain, shuffle } from "../lib/text";
import { Button, Card, Chip, OptionButton, PageHeader, Ruby, levelTone } from "../components/ui";
import { cn } from "../utils/cn";

export default function Reading() {
  const { state } = useStore();
  const [open, setOpen] = useState<Passage | null>(null);

  if (open) return <Reader p={open} onExit={() => setOpen(null)} />;

  return (
    <div>
      <PageHeader
        kanji="読"
        eyebrow="Чадвар · Уншлага"
        title="Уншиж ойлгох — 読解"
        sub="Түвшин бүрд JLPT-ийн 読解 хэсгийн хэв маягтай эх. Эхлээд асуултаа уншаад, дараа нь эхээс хариултын түлхүүр үгийг хай."
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {LEVELS.flatMap((lv) => PASSAGES.filter((p) => p.level === lv)).map((p) => {
          const t = levelTone(p.level);
          const done = state.readingDone.includes(p.id);
          const chars = plain(p.text).length;
          return (
            <button key={p.id} onClick={() => setOpen(p)} className="group text-left">
              <Card className="relative h-full overflow-hidden p-6 transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-[0_24px_50px_-30px_rgba(28,27,24,0.6)]">
                <div className="pointer-events-none absolute -bottom-8 -right-3 select-none font-mincho text-[8rem] font-black leading-none text-sumi-900/[0.04]">
                  {plain(p.title).slice(0, 1)}
                </div>
                <div className="relative">
                  <div className="flex items-center gap-2">
                    <Chip className={t.solid}>{p.level}</Chip>
                    <Chip className="bg-washi-200 text-sumi-600">{p.kind}</Chip>
                    {done && <Chip className="bg-matcha-50 text-matcha-600">✓ Уншсан</Chip>}
                  </div>
                  <h3 className="mt-4 text-[1.5rem] font-bold leading-snug text-sumi-900">
                    <Ruby text={p.title} />
                  </h3>
                  <p className="mt-1 text-[13.5px] font-semibold text-sumi-500">{p.titleMn}</p>
                  <p className="mt-4 line-clamp-2 font-jp text-[13.5px] leading-relaxed text-sumi-600">{plain(p.text)}</p>
                  <div className="mt-5 flex items-center gap-4 font-mono text-[11px] font-bold text-sumi-400">
                    <span>{chars} тэмдэгт</span>
                    <span>{p.qs.length} асуулт</span>
                    <span>~{Math.max(2, Math.round(chars / (p.level === "N5" ? 120 : p.level === "N1" ? 400 : 250)))} мин</span>
                  </div>
                </div>
              </Card>
            </button>
          );
        })}
      </div>

      <Card className="mt-6 p-6">
        <h3 className="text-[1.05rem] font-extrabold">JLPT уншлагын стратеги</h3>
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          {[
            ["先に設問", "Асуултыг эхэлж унш", "Юу хайхаа мэдсэн үед эхийг 2 дахин хурдан уншина."],
            ["接続詞", "Холбох үгийг ажигла", "しかし・つまり・一方で — зохиогчийн гол санаа эдгээрийн ард байдаг."],
            ["時間配分", "Цагаа хуваарил", "N2-N1: богино эх 2-3 мин, урт эх 8-10 мин. Гацвал алгас."],
          ].map(([jp, t, d]) => (
            <div key={jp} className="rounded-xl border border-sumi-900/10 bg-white/60 p-4">
              <p className="font-jp text-[1.15rem] font-bold text-shu-600">{jp}</p>
              <p className="mt-1 text-[13.5px] font-extrabold">{t}</p>
              <p className="mt-1 text-[12.5px] leading-relaxed text-sumi-600">{d}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Reader({ p, onExit }: { p: Passage; onExit: () => void }) {
  const { state, actions } = useStore();
  const [furi, setFuri] = useState(state.profile.furigana);
  const [mn, setMn] = useState(false);
  const [size, setSize] = useState(18);
  const [playing, setPlaying] = useState(false);
  const qs = useMemo(
    () =>
      p.qs.map((q) => {
        const correct = q.opts[q.ans];
        const opts = shuffle(q.opts);
        return { ...q, opts, ans: opts.indexOf(correct) };
      }),
    [p],
  );
  const [picked, setPicked] = useState<(number | null)[]>(() => qs.map(() => null));
  const answered = picked.filter((x) => x !== null).length;
  const correct = picked.filter((x, i) => x === qs[i].ans).length;
  const t = levelTone(p.level);

  const choose = (qi: number, k: number) => {
    if (picked[qi] !== null) return;
    const next = picked.slice();
    next[qi] = k;
    setPicked(next);
    const q = qs[qi];
    if (k !== q.ans) {
      actions.addMistakes([
        { id: `rd-${p.id}-${qi}`, kind: "Уншиж ойлгох", level: p.level, prompt: q.q, answer: q.opts[q.ans], given: q.opts[k], note: q.why },
      ]);
    }
    if (next.every((x) => x !== null)) {
      actions.markReading(p.id);
      actions.addXP(10 + next.filter((x, i) => x === qs[i].ans).length * 3);
    }
  };

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-5 flex flex-wrap items-center gap-2">
        <button
          onClick={() => {
            stopSpeaking();
            onExit();
          }}
          className="grid h-9 w-9 place-items-center rounded-xl border border-sumi-900/10 bg-white/70"
          aria-label="Буцах"
        >
          ←
        </button>
        <Chip className={t.solid}>{p.level}</Chip>
        <span className="text-[13px] font-bold text-sumi-500">{LEVEL_META[p.level].name} · {p.kind}</span>
        <div className="ml-auto flex flex-wrap gap-1.5">
          <button onClick={() => setFuri((x) => !x)} className={cn("rounded-lg border px-3 py-1.5 text-[12px] font-bold", furi ? "border-sumi-900 bg-sumi-900 text-washi-50" : "border-sumi-900/12 bg-white/70")}>
            ふりがな
          </button>
          <button onClick={() => setMn((x) => !x)} className={cn("rounded-lg border px-3 py-1.5 text-[12px] font-bold", mn ? "border-sumi-900 bg-sumi-900 text-washi-50" : "border-sumi-900/12 bg-white/70")}>
            Орчуулга
          </button>
          <button onClick={() => setSize((s) => Math.max(15, s - 1.5))} className="rounded-lg border border-sumi-900/12 bg-white/70 px-2.5 py-1.5 text-[12px] font-bold">
            A−
          </button>
          <button onClick={() => setSize((s) => Math.min(26, s + 1.5))} className="rounded-lg border border-sumi-900/12 bg-white/70 px-2.5 py-1.5 text-[12px] font-bold">
            A+
          </button>
          <button
            onClick={() => {
              if (playing) {
                stopSpeaking();
                setPlaying(false);
              } else {
                setPlaying(true);
                speak(plain(p.text), state.profile.rate * 0.95, () => setPlaying(false));
              }
            }}
            className={cn("rounded-lg border px-3 py-1.5 text-[12px] font-bold", playing ? "border-shu-500 bg-shu-500 text-white" : "border-sumi-900/12 bg-white/70")}
          >
            {playing ? "■ Зогсоох" : "▶ Чангаар унших"}
          </button>
        </div>
      </div>

      <Card className="relative overflow-hidden px-6 py-8 sm:px-10 sm:py-10">
        <div className="pointer-events-none absolute inset-y-0 left-0 w-1.5 bg-shu-500" />
        <h1 className="text-[1.9rem] font-bold leading-snug text-sumi-900">
          <Ruby text={p.title} furigana={furi} />
        </h1>
        <p className="mt-1 text-[14px] font-semibold text-sumi-500">{p.titleMn}</p>
        <div className="mt-6 font-jp leading-[2.3] text-sumi-800" style={{ fontSize: size }}>
          <Ruby text={p.text} furigana={furi} />
        </div>
        {mn && (
          <div className="mt-6 animate-rise rounded-xl border border-ai-400/30 bg-ai-50 p-5">
            <p className="font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-ai-500">Монгол орчуулга</p>
            <p className="mt-2 text-[14.5px] leading-relaxed text-sumi-700">{p.mn}</p>
          </div>
        )}
      </Card>

      <div className="mt-6 space-y-4">
        <div className="flex items-baseline justify-between">
          <h2 className="text-[1.1rem] font-extrabold">問題 · Асуулт</h2>
          <span className="font-mono text-[12px] font-bold text-sumi-500 tabnum">
            {answered}/{qs.length} · ✓{correct}
          </span>
        </div>
        {qs.map((q, qi) => (
          <Card key={qi} className="p-5">
            <p className="text-[1.05rem] font-bold leading-[2]">
              <span className="mr-2 font-mono text-[12px] text-shu-600">問{qi + 1}</span>
              <Ruby text={q.q} furigana={furi} />
            </p>
            <div className="mt-3 grid gap-2">
              {q.opts.map((o, k) => (
                <OptionButton
                  key={k}
                  idx={k}
                  disabled={picked[qi] !== null}
                  onClick={() => choose(qi, k)}
                  state={picked[qi] === null ? "idle" : k === q.ans ? "correct" : k === picked[qi] ? "wrong" : "dim"}
                >
                  <Ruby text={o} furigana={furi} />
                </OptionButton>
              ))}
            </div>
            {picked[qi] !== null && <p className="mt-3 font-jp text-[13px] leading-relaxed text-sumi-600">💡 {q.why}</p>}
          </Card>
        ))}
        {answered === qs.length && (
          <Card className="animate-pop p-6 text-center">
            <p className="text-[1.3rem] font-extrabold">
              {correct}/{qs.length} зөв {correct === qs.length ? "· 完璧!" : ""}
            </p>
            <Button className="mt-4" onClick={onExit}>
              Бусад эх рүү
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
