import { useState } from "react";
import { LEVELS, LEVEL_META, type Level } from "../data/levels";
import { useStore } from "../lib/store";
import { focusLevel, levelStats } from "../lib/progress";
import { buildPlacement, placementResult, type Question } from "../lib/exam";
import Quiz from "../components/Quiz";
import type { Route } from "../components/Shell";
import { Bar, Button, Card, PageHeader, levelTone } from "../components/ui";
import { cn } from "../utils/cn";

export default function Roadmap({ go }: { go: (r: Route) => void }) {
  const { state, actions } = useStore();
  const [test, setTest] = useState<Question[] | null>(null);
  const [placed, setPlaced] = useState<Level | "zero" | null>(null);
  const focus = focusLevel(state);

  if (test)
    return (
      <Quiz
        questions={test}
        title="Түвшин тогтоох тест"
        recordMistakes={false}
        finishLabel="Үр дүнг харах"
        onExit={() => setTest(null)}
        onFinish={({ answers }) => {
          const r = placementResult(test, answers);
          actions.setPlacement(r);
          if (r !== "zero") actions.setProfile({ target: LEVELS[Math.min(4, LEVELS.indexOf(r) + 1)] });
          setPlaced(r);
          setTest(null);
        }}
      />
    );

  return (
    <div>
      <PageHeader
        kanji="道"
        eyebrow="Эхлэл · Замын зураг"
        title="N5-аас N1 хүртэлх зам"
        sub="Таван буудал. Буудал бүрд хүрэх үг, ханз, дүрэм, уншлагын зорилт болон «юу чаддаг болох вэ» гэсэн тодорхой үр дүн бий."
        right={
          <Button onClick={() => setTest(buildPlacement())}>
            {state.placement ? "Түвшнээ дахин тогтоох" : "Түвшнээ тогтоох · 15 асуулт"}
          </Button>
        }
      />

      {placed !== null && (
        <Card className="mb-6 animate-pop border-ai-400/40 bg-ai-50 p-5">
          <p className="text-[15px] font-extrabold text-ai-600">
            {placed === "zero" ? "Суурь буюу хирагана, N5-аас эхлэхийг зөвлөж байна." : `Таны одоогийн түвшин ойролцоогоор ${placed}. Дараагийн зорилт: ${LEVELS[Math.min(4, LEVELS.indexOf(placed) + 1)]}.`}
          </p>
          <p className="mt-1 text-[12.5px] text-sumi-600">Энэ нь 15 асуултын баримжаа. Жишиг шалгалтаар нарийвчилж болно.</p>
          <div className="mt-3 flex gap-2">
            <Button size="sm" onClick={() => go(placed === "zero" ? "kana" : "plan")}>
              {placed === "zero" ? "Кана-гаас эхлэх" : "Төлөвлөгөө гаргах"}
            </Button>
            <Button size="sm" variant="outline" onClick={() => go("exam")}>
              Жишиг шалгалт
            </Button>
          </div>
        </Card>
      )}

      <div className="relative">
        <div className="absolute bottom-6 left-[27px] top-6 w-1 rounded-full bg-gradient-to-b from-matcha-400 via-kin-400 to-murasaki-400 opacity-40 sm:left-[35px]" />

        <ol className="space-y-5">
          <li className="relative flex gap-4 sm:gap-6">
            <span className="relative z-10 grid h-14 w-14 shrink-0 place-items-center rounded-2xl border-2 border-sumi-900/15 bg-washi-50 font-jp text-[1.5rem] font-bold sm:h-[72px] sm:w-[72px]">
              あ
            </span>
            <Card className="flex-1 p-5">
              <div className="flex flex-wrap items-center gap-3">
                <h3 className="text-[1.15rem] font-extrabold">0 · Кана</h3>
                <span className="text-[12.5px] text-sumi-500">1–3 долоо хоног</span>
                <span className="ml-auto font-mono text-[12px] font-bold text-sumi-600">Шилдэг сорил {state.kanaBest}%</span>
              </div>
              <p className="mt-1.5 text-[13.5px] text-sumi-600">Хирагана 46 + катакана 46, дуудлагын өөрчлөлт, нийлмэл авиа. Бүх зүйлийн суурь.</p>
              <Bar value={state.kanaBest / 100} barClass="bg-sumi-900" className="mt-3" />
              <Button size="sm" variant="outline" className="mt-3" onClick={() => go("kana")}>
                Кана руу →
              </Button>
            </Card>
          </li>

          {LEVELS.map((lv) => {
            const m = LEVEL_META[lv];
            const s = levelStats(state, lv);
            const t = levelTone(lv);
            const isFocus = lv === focus;
            return (
              <li key={lv} className="relative flex gap-4 sm:gap-6">
                <span
                  className={cn(
                    "relative z-10 grid h-14 w-14 shrink-0 place-items-center rounded-2xl font-mono text-[1.1rem] font-bold sm:h-[72px] sm:w-[72px] sm:text-[1.35rem]",
                    s.passedMock ? t.solid : isFocus ? cn(t.solid, "ring-4 ring-sumi-900/15 ring-offset-2 ring-offset-washi-100") : cn("border-2 bg-washi-50", t.ring, t.text),
                  )}
                >
                  {s.passedMock ? "✓" : lv}
                </span>
                <Card className={cn("flex-1 overflow-hidden", isFocus && "shadow-[0_24px_50px_-30px_rgba(28,27,24,0.6)]")}>
                  <div className={cn("relative px-5 py-5 sm:px-6", isFocus ? t.soft : "")}>
                    <div className="pointer-events-none absolute -right-2 -top-6 select-none font-mincho text-[6.5rem] font-black leading-none text-sumi-900/[0.04]">{m.jp}</div>
                    <div className="relative flex flex-wrap items-center gap-3">
                      <h3 className="text-[1.25rem] font-extrabold">
                        {lv} · {m.name}
                      </h3>
                      {isFocus && <span className={cn("rounded-full px-2.5 py-1 text-[11px] font-bold", t.solid)}>Одоогийн чиглэл</span>}
                      <span className="ml-auto text-[1.4rem] font-extrabold tabnum">{Math.round(s.pct * 100)}%</span>
                    </div>
                    <p className="relative mt-1.5 max-w-2xl text-[13.5px] leading-relaxed text-sumi-600">{m.desc}</p>
                    <Bar value={s.pct} barClass={t.bar} className="relative mt-3" />
                  </div>

                  <div className="grid gap-5 border-t border-sumi-900/[0.07] px-5 py-5 sm:grid-cols-[1fr_1.1fr] sm:px-6">
                    <div>
                      <p className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-sumi-500">Чаддаг болох зүйл</p>
                      <ul className="mt-2 space-y-1.5">
                        {m.can.map((c) => (
                          <li key={c} className="flex gap-2 text-[13px] text-sumi-700">
                            <span className={cn("mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full", t.bar)} />
                            {c}
                          </li>
                        ))}
                      </ul>
                      <p className="mt-3 text-[11.5px] text-sumi-500">
                        Нийт ~{m.kanji.toLocaleString()} ханз · ~{m.vocab.toLocaleString()} үг · {m.hours[0]}–{m.hours[1]} цаг (тэгээс)
                      </p>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {(
                        [
                          ["語", "Үг", s.vocab, "vocab"],
                          ["漢", "Ханз", s.kanji, "kanji"],
                          ["文", "Дүрэм", s.grammar, "grammar"],
                          ["読", "Уншлага", s.reading, "reading"],
                        ] as [string, string, [number, number], Route][]
                      ).map(([k, l, v, r]) => (
                        <button key={l} onClick={() => go(r)} className="rounded-xl border border-sumi-900/10 bg-white/60 p-3 text-left transition hover:-translate-y-0.5 hover:bg-white">
                          <div className="flex items-center justify-between">
                            <span className="font-mincho text-[15px] font-bold text-sumi-700">{k}</span>
                            <span className="font-mono text-[11.5px] font-bold tabnum">
                              {v[0]}/{v[1]}
                            </span>
                          </div>
                          <p className="mt-0.5 text-[11.5px] font-bold text-sumi-500">{l}</p>
                          <Bar value={v[1] ? v[0] / v[1] : 0} barClass={t.bar} className="mt-2" />
                        </button>
                      ))}
                      <button onClick={() => go("exam")} className="col-span-2 flex items-center justify-between rounded-xl border border-sumi-900/10 bg-white/60 px-3 py-2.5 text-left transition hover:bg-white">
                        <span className="text-[12.5px] font-bold text-sumi-700">試 Жишиг шалгалт</span>
                        <span className={cn("font-mono text-[12px] font-bold tabnum", s.passedMock ? "text-matcha-600" : "text-sumi-500")}>
                          {s.bestMock !== null ? `${s.bestMock}/180 ${s.passedMock ? "· 合格" : ""}` : `Тэнцэх ${m.passTotal}`}
                        </span>
                      </button>
                    </div>
                  </div>
                </Card>
              </li>
            );
          })}
        </ol>
      </div>
    </div>
  );
}
