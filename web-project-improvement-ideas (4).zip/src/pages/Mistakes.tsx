import { useMemo, useState } from "react";
import { LEVELS, type Level } from "../data/levels";
import { useStore } from "../lib/store";
import { Button, Card, Chip, Empty, PageHeader, Ruby, levelTone } from "../components/ui";
import type { Route } from "../components/Shell";
import { cn } from "../utils/cn";

export default function Mistakes({ go }: { go: (r: Route) => void }) {
  const { state, actions } = useStore();
  const [lv, setLv] = useState<Level | "all">("all");
  const [kind, setKind] = useState<string>("all");
  const [reveal, setReveal] = useState<Record<string, boolean>>({});

  const kinds = useMemo(() => Array.from(new Set(state.mistakes.map((m) => m.kind))), [state.mistakes]);
  const list = state.mistakes.filter((m) => (lv === "all" || m.level === lv) && (kind === "all" || m.kind === kind));

  const DAY = 864e5;
  const dueReview = state.mistakes.filter((m) => {
    const age = (Date.now() - m.at) / DAY;
    return age >= 1;
  }).length;

  return (
    <div>
      <PageHeader
        kanji="誤"
        eyebrow="Шалгалт · Алдааны дэвтэр"
        title="Алдааны дэвтэр"
        sub="Бүх буруу хариулт энд автоматаар хадгалагдана. Хариуг нь нуугаад өөрөө санаж үз, ойлгосон бол «Ойлголоо» дар. 1 · 3 · 7 хоногийн дараа дахин шалга."
        right={
          state.mistakes.length > 0 ? (
            <Button variant="ghost" size="sm" onClick={() => window.confirm("Бүх алдааг устгах уу?") && actions.clearMistakes()}>
              Бүгдийг арилгах
            </Button>
          ) : undefined
        }
      />

      {state.mistakes.length === 0 ? (
        <Empty kanji="空" title="Алдааны дэвтэр хоосон" sub="Сорил, шалгалт өгөхөд буруу хариулт энд цуглана. Алдаа бол хамгийн сайн багш." action={<Button onClick={() => go("exam")}>Жишиг шалгалт өгөх</Button>} />
      ) : (
        <>
          <div className="mb-5 grid gap-3 sm:grid-cols-3">
            <Card className="p-5">
              <p className="text-[2rem] font-extrabold leading-none tabnum">{state.mistakes.length}</p>
              <p className="mt-1.5 text-[12px] font-bold text-sumi-500">Нийт алдаа</p>
            </Card>
            <Card className="p-5">
              <p className="text-[2rem] font-extrabold leading-none tabnum text-shu-600">{dueReview}</p>
              <p className="mt-1.5 text-[12px] font-bold text-sumi-500">1+ хоногийн өмнөх · давтах цаг болсон</p>
            </Card>
            <Card className="p-5">
              <p className="text-[2rem] font-extrabold leading-none tabnum">{state.mistakes.filter((m) => m.count > 1).length}</p>
              <p className="mt-1.5 text-[12px] font-bold text-sumi-500">Давтан алдсан</p>
            </Card>
          </div>

          <div className="mb-4 flex flex-wrap gap-1.5">
            {(["all", ...LEVELS] as (Level | "all")[]).map((l) => (
              <button
                key={l}
                onClick={() => setLv(l)}
                className={cn("rounded-lg border px-3 py-1.5 text-[12px] font-bold", lv === l ? "border-sumi-900 bg-sumi-900 text-washi-50" : "border-sumi-900/12 bg-white/60 text-sumi-600")}
              >
                {l === "all" ? "Бүх түвшин" : l}
              </button>
            ))}
            <span className="mx-1 w-px bg-sumi-900/10" />
            {["all", ...kinds].map((k) => (
              <button
                key={k}
                onClick={() => setKind(k)}
                className={cn("rounded-lg border px-3 py-1.5 text-[12px] font-bold", kind === k ? "border-shu-500 bg-shu-500 text-white" : "border-sumi-900/12 bg-white/60 text-sumi-600")}
              >
                {k === "all" ? "Бүх төрөл" : k}
              </button>
            ))}
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            {list.map((m) => {
              const open = reveal[m.id];
              const t = levelTone(m.level);
              return (
                <Card key={m.id} className="flex flex-col p-5">
                  <div className="flex items-center gap-2">
                    <Chip className={t.solid}>{m.level}</Chip>
                    <span className="text-[12px] font-bold text-sumi-500">{m.kind}</span>
                    {m.count > 1 && <Chip className="bg-shu-50 text-shu-600">×{m.count}</Chip>}
                    <span className="ml-auto text-[11px] text-sumi-400">{new Date(m.at).toLocaleDateString("mn-MN")}</span>
                  </div>
                  <p className="mt-3 text-[1.1rem] leading-[2]">
                    <Ruby text={m.prompt} />
                  </p>
                  <p className="mt-1 text-[12.5px] text-shu-600">
                    Таны хариулт: <Ruby text={m.given} />
                  </p>
                  {open ? (
                    <div className="mt-3 animate-rise rounded-xl bg-matcha-50 p-3">
                      <p className="text-[13.5px] font-bold text-matcha-600">
                        ✓ <Ruby text={m.answer} />
                      </p>
                      {m.note && <p className="mt-1 font-jp text-[12.5px] text-sumi-600">{m.note}</p>}
                    </div>
                  ) : null}
                  <div className="mt-auto flex gap-2 pt-4">
                    <Button size="sm" variant="outline" onClick={() => setReveal((r) => ({ ...r, [m.id]: !r[m.id] }))}>
                      {open ? "Нуух" : "Хариуг харах"}
                    </Button>
                    <Button
                      size="sm"
                      variant="soft"
                      className="ml-auto"
                      onClick={() => {
                        actions.resolveMistake(m.id);
                        actions.addXP(2);
                      }}
                    >
                      ✓ Ойлголоо
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
