import { useEffect, useMemo, useRef, useState } from "react";
import { LEVELS, LEVEL_META, fmtDate, nextJlptDates, daysUntil, type Level } from "../data/levels";
import { useStore } from "../lib/store";
import { buildMock, scoreExam, type Question, type Scored } from "../lib/exam";
import { speak } from "../lib/speech";
import { QuestionView } from "../components/Quiz";
import { Button, Card, Chip, OptionButton, PageHeader, Ruby, levelTone } from "../components/ui";
import { cn } from "../utils/cn";

const SECTION_LABEL: Record<string, string> = {
  vocab: "文字・語彙",
  grammar: "文法",
  reading: "読解",
  listening: "聴解",
};

export default function Exam() {
  const { state } = useStore();
  const [lv, setLv] = useState<Level>(state.profile.target);
  const [run, setRun] = useState<{ lv: Level; qs: Question[] } | null>(null);
  const [result, setResult] = useState<{ lv: Level; qs: Question[]; answers: (number | null)[]; s: Scored } | null>(null);

  if (result) return <Result {...result} onExit={() => setResult(null)} onRetry={() => { setResult(null); setRun({ lv: result.lv, qs: buildMock(result.lv) }); }} />;
  if (run) return <Runner lv={run.lv} qs={run.qs} onExit={() => setRun(null)} onSubmit={(answers, s) => { setResult({ lv: run.lv, qs: run.qs, answers, s }); setRun(null); }} />;

  const meta = LEVEL_META[lv];
  const t = levelTone(lv);
  const next = nextJlptDates()[0];
  const history = state.exams.slice(0, 8);

  return (
    <div>
      <PageHeader
        kanji="試"
        eyebrow="JLPT Prep Center · N5–N1"
        title="JLPT жишиг шалгалт"
        sub="Албан ёсны оноо (0–180), хэсэг тус бүрийн босго оноогоор тооцох мини шалгалт. Дуусахад алдаа бүр тайлбартай, алдааны дэвтэрт автоматаар орно."
        right={
          <a
            href="https://www.jlpt.jp/e/samples/forlearners.html"
            target="_blank"
            rel="noreferrer"
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-sumi-900/15 bg-white/60 px-4 text-[13px] font-bold text-sumi-800 hover:bg-white"
          >
            Албан ёсны жишиг асуулт ↗
          </a>
        }
      />

      <div className="grid gap-3 sm:grid-cols-5">
        {LEVELS.map((l) => {
          const tt = levelTone(l);
          const on = l === lv;
          const best = state.exams.filter((e) => e.level === l);
          const top = best.length ? Math.max(...best.map((b) => b.total)) : null;
          return (
            <button
              key={l}
              onClick={() => setLv(l)}
              className={cn(
                "rounded-2xl border p-4 text-left transition-all duration-200 hover:-translate-y-0.5",
                on ? cn(tt.solid, "border-transparent shadow-lg") : "border-sumi-900/10 bg-white/60 hover:bg-white",
              )}
            >
              <p className="font-mono text-[1.35rem] font-bold">{l}</p>
              <p className={cn("text-[12px] font-bold", on ? "text-white/80" : "text-sumi-500")}>{LEVEL_META[l].name}</p>
              <p className={cn("mt-3 font-mono text-[11px] font-bold", on ? "text-white/90" : "text-sumi-600")}>
                {top !== null ? `Шилдэг ${top}/180` : `Тэнцэх ${LEVEL_META[l].passTotal}/180`}
              </p>
            </button>
          );
        })}
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1.25fr_1fr]">
        <Card className="relative overflow-hidden">
          <div className={cn("relative px-6 pb-6 pt-7 sm:px-8", t.soft)}>
            <div className="pointer-events-none absolute -right-4 -top-8 select-none font-mincho text-[10rem] font-black leading-none text-sumi-900/[0.05]">{meta.jp}</div>
            <p className={cn("relative font-mono text-[11px] font-bold uppercase tracking-[0.2em]", t.text)}>日本語能力試験 · {lv}</p>
            <h2 className="relative mt-2 text-[1.6rem] font-extrabold leading-tight">{meta.name} түвшин</h2>
            <p className="relative mt-2 max-w-lg text-[13.5px] leading-relaxed text-sumi-700">{meta.desc}</p>
          </div>
          <div className="space-y-5 px-6 py-6 sm:px-8">
            <div>
              <p className="text-[12px] font-extrabold uppercase tracking-[0.14em] text-sumi-500">Албан ёсны оноо ба босго</p>
              <div className="mt-3 overflow-hidden rounded-xl border border-sumi-900/10">
                <table className="w-full text-[13px]">
                  <thead className="bg-washi-200/60 text-left text-[11.5px] text-sumi-600">
                    <tr>
                      <th className="px-3 py-2 font-bold">Хэсэг</th>
                      <th className="px-3 py-2 text-right font-bold">Оноо</th>
                      <th className="px-3 py-2 text-right font-bold">Босго</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-sumi-900/[0.06] bg-white/60">
                    {meta.sections.map((s) => (
                      <tr key={s.jp}>
                        <td className="px-3 py-2.5">
                          <span className="font-jp font-bold">{s.jp}</span>
                          <span className="ml-2 text-[11.5px] text-sumi-500">{s.name}</span>
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono tabnum">0–{s.max}</td>
                        <td className="px-3 py-2.5 text-right font-mono font-bold tabnum text-shu-600">{s.min}</td>
                      </tr>
                    ))}
                    <tr className="bg-sumi-900 text-washi-50">
                      <td className="px-3 py-2.5 font-bold">Нийт · тэнцэх оноо</td>
                      <td className="px-3 py-2.5 text-right font-mono tabnum">0–180</td>
                      <td className="px-3 py-2.5 text-right font-mono font-bold tabnum">{meta.passTotal}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="mt-2 text-[11.5px] leading-relaxed text-sumi-500">
                Тэнцэхийн тулд нийт оноо <b>болон</b> хэсэг бүрийн босгыг зэрэг давах шаардлагатай. Жинхэнэ шалгалтын хугацаа:{" "}
                {meta.minutes.map((m, i) => `${meta.minuteLabels[i]} ${m}′`).join(" · ")}.
              </p>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center">
              {[
                ["文字・語彙", "10"],
                ["文法", "≤6"],
                ["読解", String(LEVEL_META[lv] ? (lv === "N2" ? 2 : 3) : 3)],
                ["聴解", "4"],
              ].map(([k, n]) => (
                <div key={k} className="rounded-xl border border-sumi-900/10 bg-white/60 py-3">
                  <p className="text-[1.25rem] font-extrabold tabnum">{n}</p>
                  <p className="font-jp text-[11px] font-bold text-sumi-500">{k}</p>
                </div>
              ))}
            </div>

            <Button size="lg" className="w-full" onClick={() => setRun({ lv, qs: buildMock(lv) })}>
              {lv} мини шалгалт эхлүүлэх · {meta.mockMinutes} мин
            </Button>
          </div>
        </Card>

        <div className="space-y-5">
          <Card className="relative overflow-hidden bg-sumi-900 p-6 text-washi-50">
            <div className="seigaiha pointer-events-none absolute inset-0 text-white/[0.04]" />
            <p className="relative font-mono text-[10.5px] font-bold uppercase tracking-[0.22em] text-shu-400">Дараагийн JLPT</p>
            <p className="relative mt-2 text-[2.4rem] font-extrabold leading-none tabnum">{daysUntil(next)} хоног</p>
            <p className="relative mt-2 text-[13px] text-washi-300">{fmtDate(next)} (ням) · жилд 2 удаа, 7 ба 12-р сарын эхний ням гарагт</p>
            <p className="relative mt-3 text-[12px] text-washi-400">Монголд бүртгэлийг ихэвчлэн шалгалтаас ~3–4 сарын өмнө зарладаг. Огноо, бүртгэлийг албан ёсны эх сурвалжаас шалгаарай.</p>
            <a href="https://www.jlpt.jp/e/" target="_blank" rel="noreferrer" className="relative mt-4 inline-block text-[12.5px] font-bold text-shu-400 hover:underline">
              jlpt.jp ↗
            </a>
          </Card>

          <Card className="p-6">
            <h3 className="text-[1.05rem] font-extrabold">Шалгалтын түүх</h3>
            {history.length === 0 ? (
              <p className="mt-3 text-[13px] text-sumi-500">Одоогоор шалгалт өгөөгүй байна. Эхний оноо чинь бол таны суурь хэмжүүр.</p>
            ) : (
              <ul className="mt-4 space-y-2">
                {history.map((h, i) => {
                  const tt = levelTone(h.level);
                  return (
                    <li key={i} className="flex items-center gap-3 rounded-xl border border-sumi-900/[0.07] bg-white/60 px-3.5 py-2.5">
                      <Chip className={tt.solid}>{h.level}</Chip>
                      <span className="text-[12px] text-sumi-500">{new Date(h.at).toLocaleDateString("mn-MN")}</span>
                      <span className="ml-auto font-mono text-[14px] font-bold tabnum">{h.total}/180</span>
                      <span className={cn("hanko grid h-8 w-8 place-items-center rounded-md text-[11px] font-black", h.passed ? "text-matcha-600" : "text-shu-500")}>
                        {h.passed ? "合" : "否"}
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>

          <Card className="p-6">
            <h3 className="text-[1.05rem] font-extrabold">Ихийг бус, зөвийг давт</h3>
            <ol className="mt-3 space-y-2.5 text-[13px] leading-relaxed text-sumi-700">
              <li><b>1.</b> Эхлээд түвшнээ оношил — нэг бүтэн жишиг шалгалт.</li>
              <li><b>2.</b> Хамгийн сул хэсэгтээ долоо хоногийн цагийн 40%-ийг зарцуул.</li>
              <li><b>3.</b> Алдааны дэвтрээ 1 · 3 · 7 хоногийн дараа дахин шалга.</li>
              <li><b>4.</b> Шалгалтаас 4 долоо хоногийн өмнөөс 7 хоног бүр жишиг шалгалт.</li>
            </ol>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
function Runner({ lv, qs, onExit, onSubmit }: { lv: Level; qs: Question[]; onExit: () => void; onSubmit: (a: (number | null)[], s: Scored) => void }) {
  const { state } = useStore();
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(() => qs.map(() => null));
  const [flags, setFlags] = useState<boolean[]>(() => qs.map(() => false));
  const [left, setLeft] = useState(LEVEL_META[lv].mockMinutes * 60);
  const [confirm, setConfirm] = useState(false);
  const q = qs[i];

  const submit = () => onSubmit(answers, scoreExam(lv, qs, answers));

  useEffect(() => {
    const t = window.setInterval(() => setLeft((x) => x - 1), 1000);
    return () => window.clearInterval(t);
  }, []);
  useEffect(() => {
    if (left <= 0) submit();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [left <= 0]);
  useEffect(() => {
    if (q?.speak) {
      const t = window.setTimeout(() => speak(q.speak!, state.profile.rate), 300);
      return () => window.clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i]);

  const mm = String(Math.max(0, Math.floor(left / 60))).padStart(2, "0");
  const ss = String(Math.max(0, left % 60)).padStart(2, "0");
  const answered = answers.filter((a) => a !== null).length;
  const sections = Array.from(new Set(qs.map((x) => x.section)));

  return (
    <div className="mx-auto max-w-5xl">
      <div className="sticky top-16 z-30 -mx-4 mb-5 border-b border-sumi-900/10 bg-washi-100/95 px-4 py-3 backdrop-blur lg:top-0">
        <div className="flex items-center gap-3">
          <button onClick={() => window.confirm("Шалгалтаас гарах уу? Ахиц хадгалагдахгүй.") && onExit()} className="grid h-9 w-9 place-items-center rounded-xl border border-sumi-900/10 bg-white/70" aria-label="Гарах">
            ✕
          </button>
          <Chip className={levelTone(lv).solid}>{lv}</Chip>
          <span className="hidden font-jp text-[13px] font-bold text-sumi-600 sm:inline">{SECTION_LABEL[q.section]}</span>
          <span className={cn("ml-auto rounded-xl px-3 py-1.5 font-mono text-[15px] font-bold tabnum", left < 120 ? "animate-pulse bg-shu-500 text-white" : "bg-sumi-900 text-washi-50")}>
            {mm}:{ss}
          </span>
          <Button size="sm" onClick={() => setConfirm(true)}>
            Илгээх
          </Button>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_250px]">
        <div>
          <div key={i} className="animate-rise">
            <QuestionView q={q} />
            <div className="mt-4 grid gap-2">
              {q.options.map((o, k) => (
                <OptionButton
                  key={k}
                  idx={k}
                  onClick={() => setAnswers((a) => a.map((x, j) => (j === i ? k : x)))}
                  state={answers[i] === k ? "picked" : "idle"}
                >
                  <Ruby text={o} />
                </OptionButton>
              ))}
            </div>
          </div>
          <div className="mt-5 flex items-center gap-2">
            <Button variant="outline" disabled={i === 0} onClick={() => setI((x) => x - 1)}>
              ← Өмнөх
            </Button>
            <button
              onClick={() => setFlags((f) => f.map((x, j) => (j === i ? !x : x)))}
              className={cn("h-11 rounded-xl border px-4 text-[13px] font-bold", flags[i] ? "border-kin-500 bg-kin-50 text-kin-600" : "border-sumi-900/12 bg-white/60 text-sumi-600")}
            >
              ⚑ {flags[i] ? "Тэмдэглэсэн" : "Дараа шалгах"}
            </button>
            <Button className="ml-auto" variant="ink" onClick={() => (i < qs.length - 1 ? setI((x) => x + 1) : setConfirm(true))}>
              {i < qs.length - 1 ? "Дараах →" : "Дуусгах"}
            </Button>
          </div>
        </div>

        <Card className="self-start p-4 lg:sticky lg:top-24">
          <p className="text-[12.5px] font-bold text-sumi-600">
            Хариулсан <span className="tabnum">{answered}/{qs.length}</span>
          </p>
          <div className="mt-3 space-y-3">
            {sections.map((sec) => (
              <div key={sec}>
                <p className="mb-1.5 font-jp text-[11.5px] font-bold text-sumi-500">{SECTION_LABEL[sec]}</p>
                <div className="grid grid-cols-6 gap-1.5">
                  {qs.map((qq, k) =>
                    qq.section !== sec ? null : (
                      <button
                        key={k}
                        onClick={() => setI(k)}
                        className={cn(
                          "relative grid h-8 place-items-center rounded-lg font-mono text-[11px] font-bold transition-all",
                          k === i ? "bg-shu-500 text-white" : answers[k] !== null ? "bg-sumi-900 text-washi-50" : "bg-washi-200 text-sumi-500 hover:bg-washi-300",
                        )}
                      >
                        {k + 1}
                        {flags[k] && <i className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-kin-500 ring-2 ring-washi-50" />}
                      </button>
                    ),
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {confirm && (
        <div className="fixed inset-0 z-[60] grid place-items-center bg-sumi-950/50 p-6 backdrop-blur-sm" onClick={() => setConfirm(false)}>
          <Card className="w-full max-w-sm animate-pop p-6 text-center" onClick={() => undefined}>
            <div onClick={(e) => e.stopPropagation()}>
              <p className="font-mincho text-[2.6rem] font-black text-shu-500">提出</p>
              <p className="mt-2 text-[15px] font-extrabold">Шалгалтаа илгээх үү?</p>
              <p className="mt-1 text-[13px] text-sumi-500">
                {qs.length - answered > 0 ? `${qs.length - answered} асуулт хариулаагүй байна.` : "Бүх асуултад хариулсан."}
              </p>
              <div className="mt-5 grid grid-cols-2 gap-2">
                <Button variant="outline" onClick={() => setConfirm(false)}>
                  Буцах
                </Button>
                <Button onClick={submit}>Илгээх</Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
function Result({ lv, qs, answers, s, onExit, onRetry }: { lv: Level; qs: Question[]; answers: (number | null)[]; s: Scored; onExit: () => void; onRetry: () => void }) {
  const { actions } = useStore();
  const meta = LEVEL_META[lv];
  const wrong = useMemo(() => qs.map((q, i) => ({ q, a: answers[i] })).filter((x) => x.a !== x.q.answer), [qs, answers]);
  const saved = useRef(false);

  useEffect(() => {
    if (saved.current) return;
    saved.current = true;
    actions.recordExam({ level: lv, at: Date.now(), total: s.total, sections: s.scaled, passed: s.passed, correct: s.correct, count: qs.length });
    actions.addXP(20 + s.correct * 2);
    actions.addMistakes(
      wrong.map(({ q, a }) => ({
        id: q.id,
        kind: q.kindMn,
        level: q.level,
        prompt: q.speak ? `🔊 ${q.speak}` : q.prompt,
        answer: q.options[q.answer],
        given: a === null ? "(хариулаагүй)" : q.options[a],
        note: q.explain,
      })),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <Card className="relative overflow-hidden">
        <div className={cn("relative grid gap-6 p-6 sm:grid-cols-[1fr_auto] sm:items-center sm:p-9", s.passed ? "bg-matcha-50" : "bg-shu-50")}>
          <div>
            <p className="font-mono text-[11px] font-bold uppercase tracking-[0.2em] text-sumi-500">JLPT {lv} · Мини жишиг шалгалт</p>
            <p className="mt-3 text-[3.6rem] font-extrabold leading-none tabnum">
              {s.total}
              <span className="text-[1.4rem] text-sumi-400">/180</span>
            </p>
            <p className="mt-2 text-[14px] text-sumi-700">
              Тэнцэх оноо {meta.passTotal} · {s.correct}/{qs.length} зөв ({Math.round((s.correct / qs.length) * 100)}%)
            </p>
          </div>
          <div
            className={cn(
              "hanko grid h-32 w-32 rotate-[-8deg] place-items-center rounded-full text-center",
              s.passed ? "text-matcha-600" : "text-shu-500",
            )}
            style={{ boxShadow: "inset 0 0 0 4px currentColor, inset 0 0 0 8px transparent, inset 0 0 0 10px currentColor" }}
          >
            <span>
              <span className="block text-[2.4rem] font-black leading-none">{s.passed ? "合格" : "不合格"}</span>
              <span className="mt-1 block font-sans text-[11px] font-bold">{s.passed ? "Тэнцсэн" : "Тэнцээгүй"}</span>
            </span>
          </div>
        </div>
        <div className="grid gap-4 p-6 sm:grid-cols-3 sm:p-8">
          {meta.sections.map((sec, i) => {
            const v = s.scaled[i];
            const ok = s.sectionPass[i];
            return (
              <div key={sec.jp} className="rounded-xl border border-sumi-900/10 bg-white/60 p-4">
                <p className="font-jp text-[13px] font-bold">{sec.jp}</p>
                <p className="text-[11.5px] text-sumi-500">{sec.name}</p>
                <p className="mt-3 text-[1.6rem] font-extrabold tabnum">
                  {v}
                  <span className="text-[13px] text-sumi-400">/{sec.max}</span>
                </p>
                <div className="relative mt-2 h-2 rounded-full bg-sumi-900/[0.07]">
                  <div className={cn("h-full rounded-full", ok ? "bg-matcha-500" : "bg-shu-500")} style={{ width: `${(v / sec.max) * 100}%` }} />
                  <i className="absolute -top-1 h-4 w-0.5 bg-sumi-900" style={{ left: `${(sec.min / sec.max) * 100}%` }} title={`Босго ${sec.min}`} />
                </div>
                <p className={cn("mt-2 text-[11.5px] font-bold", ok ? "text-matcha-600" : "text-shu-600")}>{ok ? `✓ Босго ${sec.min} давсан` : `✕ Босго ${sec.min} — ${sec.min - v} оноо дутуу`}</p>
              </div>
            );
          })}
        </div>
        <div className="flex flex-wrap gap-2 border-t border-sumi-900/[0.07] px-6 py-5 sm:px-8">
          {(Object.keys(s.bySection) as (keyof typeof s.bySection)[]).map((k) =>
            s.bySection[k].n ? (
              <span key={k} className="rounded-lg bg-washi-200 px-3 py-1.5 text-[12px] font-bold text-sumi-700">
                <span className="font-jp">{SECTION_LABEL[k]}</span> {s.bySection[k].c}/{s.bySection[k].n}
              </span>
            ) : null,
          )}
          <div className="ml-auto flex gap-2">
            <Button variant="outline" onClick={onExit}>
              Буцах
            </Button>
            <Button onClick={onRetry}>Шинэ хувилбар</Button>
          </div>
        </div>
      </Card>

      {wrong.length > 0 && (
        <Card className="p-6">
          <h3 className="text-[1.1rem] font-extrabold">Алдааны задлан шинжилгээ · {wrong.length}</h3>
          <p className="text-[12.5px] text-sumi-500">Эдгээр нь алдааны дэвтэрт хадгалагдлаа.</p>
          <ul className="mt-4 space-y-3">
            {wrong.map(({ q, a }) => (
              <li key={q.id} className="rounded-xl border border-sumi-900/[0.08] bg-white/60 p-4">
                <div className="flex items-center gap-2">
                  <span className="rounded bg-sumi-900 px-1.5 py-0.5 font-jp text-[10.5px] font-bold text-washi-50">{q.kind}</span>
                  <span className="text-[11.5px] font-bold text-sumi-500">{q.kindMn}</span>
                </div>
                <p className="mt-2 text-[1.05rem] leading-[2]">{q.speak ? `🔊 ${q.speak}` : <Ruby text={q.prompt} />}</p>
                <div className="mt-2 grid gap-1.5 text-[13px] sm:grid-cols-2">
                  <p className="rounded-lg bg-shu-50 px-3 py-2 text-shu-700">
                    ✕ <Ruby text={a === null ? "(хариулаагүй)" : q.options[a]} />
                  </p>
                  <p className="rounded-lg bg-matcha-50 px-3 py-2 text-matcha-600">
                    ✓ <Ruby text={q.options[q.answer]} />
                  </p>
                </div>
                <p className="mt-2 font-jp text-[12.5px] text-sumi-600">💡 {q.explain}</p>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}
