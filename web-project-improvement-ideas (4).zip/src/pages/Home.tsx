import { useMemo } from "react";
import { LEVELS, LEVEL_META, daysUntil, fmtDate, nextJlptDates } from "../data/levels";
import { VOCAB } from "../data/vocab";
import { grammarByLevel } from "../data/grammar";
import { useStore } from "../lib/store";
import { focusLevel, heatmap, levelStats } from "../lib/progress";
import { greetingJp, todayKey } from "../lib/text";
import type { Route } from "../components/Shell";
import { Bar, Card, Chip, Ring, Ruby, SpeakButton, levelTone } from "../components/ui";
import { cn } from "../utils/cn";

export default function Home({ go }: { go: (r: Route) => void }) {
  const { state, today, streak } = useStore();
  const p = state.profile;
  const g = greetingJp();
  const focus = focusLevel(state);
  const now = Date.now();

  const due = Object.values(state.srs).filter((c) => c.due <= now).length;
  const newLeft = Math.max(0, p.newPerDay - today.newCards);
  const nextGrammar = grammarByLevel(focus).find((x) => !state.grammarDone.includes(x.id));

  const exam = p.examDate ? new Date(p.examDate) : nextJlptDates()[0];
  const dLeft = daysUntil(exam);

  const wotd = useMemo(() => {
    const pool = VOCAB.filter((v) => v.level === focus);
    const seed = todayKey().split("-").reduce((a, b) => a * 31 + Number(b), 7);
    return pool[seed % pool.length];
  }, [focus]);

  const heat = useMemo(() => heatmap(state, 16), [state]);
  const weekMin = heat.slice(-7).reduce((a, d) => a + d.min, 0);

  const tasks = [
    {
      k: "復",
      t: "Давталт",
      d: due > 0 ? `${due} карт хүлээж байна` : "Өнөөдрийн давталт дууссан",
      done: due === 0 && Object.keys(state.srs).length > 0,
      min: 5,
      go: "vocab" as Route,
    },
    {
      k: "新",
      t: "Шинэ үг",
      d: newLeft > 0 ? `${newLeft} шинэ үг · ${focus}` : "Өнөөдрийн шинэ үг дууслаа",
      done: newLeft === 0,
      min: 5,
      go: "vocab" as Route,
    },
    {
      k: "文",
      t: "Нэг дүрэм",
      d: nextGrammar ? nextGrammar.p : `${focus} дүрэм бүгд дууссан`,
      done: !nextGrammar,
      min: 7,
      go: "grammar" as Route,
    },
    {
      k: "耳",
      t: "Сонсгол",
      d: "5 өгүүлбэр сонсоод утгыг ол",
      done: false,
      min: 3,
      go: "listening" as Route,
    },
  ];

  const goalPct = today.min / Math.max(1, p.dailyGoal);

  return (
    <div className="space-y-6">
      {/* ------------ hero ------------ */}
      <section className="relative overflow-hidden rounded-3xl bg-sumi-900 text-washi-50">
        <div className="seigaiha pointer-events-none absolute -right-10 bottom-0 h-full w-2/3 text-white/[0.045]" />
        <div className="pointer-events-none absolute -right-6 -top-10 select-none font-mincho text-[15rem] font-black leading-none text-white/[0.035]">
          道
        </div>
        <div className="relative grid gap-8 p-6 sm:p-9 lg:grid-cols-[1.35fr_1fr] lg:items-center">
          <div>
            <p className="font-mono text-[10.5px] font-semibold uppercase tracking-[0.26em] text-shu-400">
              {new Date().toLocaleDateString("mn-MN", { month: "long", day: "numeric", weekday: "long" })}
            </p>
            <h1 className="mt-3 font-jp text-[clamp(2rem,5vw,3.2rem)] font-black leading-[1.05]">
              {g.jp}
              {p.name && <span className="text-washi-400">、{p.name}</span>}
            </h1>
            <p className="mt-2 text-[15px] text-washi-300">
              {g.mn}! Өнөөдрийн гол чиглэл — <b className="text-washi-50">{focus} · {LEVEL_META[focus].name}</b>.
            </p>

            <div className="mt-7 flex flex-wrap gap-2.5">
              <button
                onClick={() => go("vocab")}
                className="group flex items-center gap-3 rounded-2xl bg-shu-500 px-5 py-3.5 text-left shadow-[0_14px_30px_-14px_rgba(224,101,76,0.9)] transition-all hover:-translate-y-0.5 hover:bg-shu-400"
              >
                <span className="font-mincho text-[1.6rem] font-black leading-none">始</span>
                <span>
                  <span className="block text-[14.5px] font-extrabold">Өнөөдрийн хичээл</span>
                  <span className="block text-[12px] text-white/80">{due + newLeft} карт · ~{p.dailyGoal} мин</span>
                </span>
              </button>
              <button
                onClick={() => go("exam")}
                className="flex items-center gap-3 rounded-2xl border border-white/15 bg-white/[0.05] px-5 py-3.5 text-left transition-all hover:-translate-y-0.5 hover:bg-white/10"
              >
                <span className="font-mincho text-[1.6rem] font-black leading-none text-washi-300">試</span>
                <span>
                  <span className="block text-[14.5px] font-extrabold">Жишиг шалгалт</span>
                  <span className="block text-[12px] text-washi-400">{p.target} · {LEVEL_META[p.target].mockMinutes} мин</span>
                </span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-3 flex items-center gap-5 rounded-2xl border border-white/10 bg-white/[0.04] p-4 sm:col-span-1 sm:flex-col sm:gap-3 sm:text-center">
              <Ring value={goalPct} size={86} stroke={8} color="#e0654c" track="rgba(255,255,255,0.08)">
                <span className="text-center leading-none">
                  <span className="block text-[1.35rem] font-extrabold tabnum">{today.min}</span>
                  <span className="text-[10px] text-washi-400">/{p.dailyGoal} мин</span>
                </span>
              </Ring>
              <p className="text-[12px] font-bold text-washi-300">Өнөөдрийн зорилго</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
              <p className="text-[1.9rem] font-extrabold leading-none tabnum">🔥{streak}</p>
              <p className="mt-2 text-[11.5px] font-bold text-washi-400">дараалсан өдөр</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
              <p className="text-[1.9rem] font-extrabold leading-none tabnum">{dLeft}</p>
              <p className="mt-2 text-[11.5px] font-bold text-washi-400">хоног · JLPT</p>
              <p className="mt-0.5 font-mono text-[10px] text-washi-500">{fmtDate(exam)}</p>
            </div>
          </div>
        </div>
      </section>

      {/* ------------ today plan + wotd ------------ */}
      <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <Card className="p-5 sm:p-6">
          <div className="flex items-baseline justify-between">
            <div>
              <h2 className="text-[1.15rem] font-extrabold">Өнөөдрийн {p.dailyGoal} минут</h2>
              <p className="text-[12.5px] text-sumi-500">Бага багаар, өдөр бүр — 毎日、少しずつ</p>
            </div>
            <span className="font-mono text-[11px] font-bold text-sumi-500 tabnum">
              {tasks.filter((t) => t.done).length}/{tasks.length}
            </span>
          </div>
          <ol className="mt-5 space-y-2">
            {tasks.map((t, i) => (
              <li key={t.t}>
                <button
                  onClick={() => go(t.go)}
                  className={cn(
                    "group flex w-full items-center gap-4 rounded-xl border px-4 py-3 text-left transition-all duration-200",
                    t.done ? "border-matcha-400/40 bg-matcha-50/70" : "border-sumi-900/10 bg-white/60 hover:-translate-y-0.5 hover:border-sumi-900/25 hover:bg-white",
                  )}
                >
                  <span className="w-5 text-center font-mono text-[11px] font-bold text-sumi-400 tabnum">{String(i + 1).padStart(2, "0")}</span>
                  <span
                    className={cn(
                      "grid h-10 w-10 shrink-0 place-items-center rounded-xl font-mincho text-[18px] font-bold",
                      t.done ? "bg-matcha-500 text-white" : "bg-washi-200 text-sumi-700 group-hover:bg-shu-500 group-hover:text-white",
                    )}
                  >
                    {t.done ? "✓" : t.k}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[14px] font-extrabold text-sumi-900">{t.t}</span>
                    <span className="block truncate text-[12.5px] text-sumi-500">{t.d}</span>
                  </span>
                  <span className="font-mono text-[11px] font-bold text-sumi-400">{t.min}′</span>
                </button>
              </li>
            ))}
          </ol>
        </Card>

        {wotd && (
          <Card className="relative overflow-hidden p-6">
            <div className="pointer-events-none absolute -bottom-6 -right-4 select-none font-mincho text-[9rem] font-black leading-none text-shu-500/[0.06]">
              {wotd.w.slice(0, 1)}
            </div>
            <div className="relative">
              <div className="flex items-center justify-between">
                <p className="font-mono text-[10.5px] font-bold uppercase tracking-[0.22em] text-shu-600">今日の言葉 · Өдрийн үг</p>
                <Chip className={cn(levelTone(wotd.level).soft, levelTone(wotd.level).text)}>{wotd.level}</Chip>
              </div>
              <div className="mt-5 flex items-end gap-3">
                <Ruby text={wotd.w === wotd.r ? wotd.w : `${wotd.w}{${wotd.r}}`} furigana className="text-[2.8rem] font-black leading-none text-sumi-900" />
                <SpeakButton text={wotd.r} className="mb-1" />
              </div>
              <p className="mt-4 text-[17px] font-extrabold text-sumi-800">{wotd.mn}</p>
              <p className="text-[13px] text-sumi-500">{wotd.en}</p>
              <button onClick={() => go("vocab")} className="mt-5 text-[12.5px] font-bold text-shu-600 underline-offset-4 hover:underline">
                {wotd.level} үгийн сан руу →
              </button>
            </div>
          </Card>
        )}
      </div>

      {/* ------------ level mastery ------------ */}
      <Card className="p-5 sm:p-6">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <div>
            <h2 className="text-[1.15rem] font-extrabold">Түвшин бүрийн ахиц</h2>
            <p className="text-[12.5px] text-sumi-500">Үг · ханз · дүрэм · уншлага · жишиг шалгалт</p>
          </div>
          <button onClick={() => go("roadmap")} className="text-[12.5px] font-bold text-shu-600 hover:underline">
            Замын зураг →
          </button>
        </div>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {LEVELS.map((lv) => {
            const s = levelStats(state, lv);
            const t = levelTone(lv);
            const isFocus = lv === focus;
            return (
              <button
                key={lv}
                onClick={() => go("roadmap")}
                className={cn(
                  "rounded-xl border p-4 text-left transition-all hover:-translate-y-0.5",
                  isFocus ? cn("bg-white", t.ring, "border-2") : "border-sumi-900/10 bg-white/50 hover:bg-white",
                )}
              >
                <div className="flex items-center justify-between">
                  <span className={cn("font-mono text-[15px] font-bold", t.text)}>{lv}</span>
                  <span className="text-[1.15rem] font-extrabold tabnum">{Math.round(s.pct * 100)}%</span>
                </div>
                <Bar value={s.pct} barClass={t.bar} className="mt-2" />
                <dl className="mt-3 grid grid-cols-2 gap-x-2 gap-y-1 text-[11px]">
                  <dt className="text-sumi-500">Үг</dt>
                  <dd className="text-right font-bold tabnum">{s.vocab[0]}/{s.vocab[1]}</dd>
                  <dt className="text-sumi-500">Ханз</dt>
                  <dd className="text-right font-bold tabnum">{s.kanji[0]}/{s.kanji[1]}</dd>
                  <dt className="text-sumi-500">Дүрэм</dt>
                  <dd className="text-right font-bold tabnum">{s.grammar[0]}/{s.grammar[1]}</dd>
                  <dt className="text-sumi-500">Шалгалт</dt>
                  <dd className={cn("text-right font-bold tabnum", s.passedMock ? "text-matcha-600" : "")}>
                    {s.bestMock !== null ? `${s.bestMock}/180` : "—"}
                  </dd>
                </dl>
                {isFocus && <p className={cn("mt-2 text-[10.5px] font-bold", t.text)}>● Одоогийн чиглэл</p>}
              </button>
            );
          })}
        </div>
      </Card>

      {/* ------------ heatmap ------------ */}
      <Card className="p-5 sm:p-6">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <div>
            <h2 className="text-[1.15rem] font-extrabold">Суралцсан өдрүүд</h2>
            <p className="text-[12.5px] text-sumi-500">Сүүлийн 16 долоо хоног · энэ 7 хоногт {weekMin} мин</p>
          </div>
          <div className="flex items-center gap-1.5 text-[10.5px] text-sumi-500">
            Бага
            {[0, 1, 2, 3, 4].map((l) => (
              <i key={l} className={cn("h-3 w-3 rounded-[3px]", ["bg-sumi-900/[0.06]", "bg-shu-100", "bg-shu-400/60", "bg-shu-500", "bg-shu-700"][l])} />
            ))}
            Их
          </div>
        </div>
        <div className="no-scrollbar mt-5 overflow-x-auto">
          <div className="grid w-max grid-flow-col grid-rows-7 gap-[3px]">
            {heat.map((d) => {
              const lvl = d.xp === 0 && d.min === 0 ? 0 : d.min < 5 ? 1 : d.min < 15 ? 2 : d.min < 30 ? 3 : 4;
              return (
                <i
                  key={d.key}
                  title={`${d.key} · ${d.min} мин · ${d.xp} XP`}
                  className={cn(
                    "h-[13px] w-[13px] rounded-[3px] transition-transform hover:scale-125",
                    ["bg-sumi-900/[0.06]", "bg-shu-100", "bg-shu-400/60", "bg-shu-500", "bg-shu-700"][lvl],
                    d.key === todayKey() && "ring-2 ring-sumi-900/40",
                  )}
                />
              );
            })}
          </div>
        </div>
      </Card>
    </div>
  );
}
