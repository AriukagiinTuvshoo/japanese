import { LEVEL_META, LEVELS, type Level } from "../data/levels";
import { VOCAB, vocabByLevel, hasKanji, type VocabItem } from "../data/vocab";
import { grammarByLevel, GRAMMAR } from "../data/grammar";
import { passagesByLevel } from "../data/reading";
import { blank, plain, sample, shuffle, target } from "./text";

export type Section = "vocab" | "grammar" | "reading" | "listening";

export interface Question {
  id: string;
  section: Section;
  kind: string;
  kindMn: string;
  level: Level;
  prompt: string;
  big?: boolean;
  passage?: { title: string; text: string };
  speak?: string;
  options: string[];
  answer: number;
  explain: string;
}

function withOptions(correct: string, distract: string[]) {
  const uniq = Array.from(new Set(distract.filter((d) => d && d !== correct))).slice(0, 3);
  const options = shuffle([correct, ...uniq]);
  return { options, answer: options.indexOf(correct) };
}

function nearPool(lv: Level) {
  const i = LEVELS.indexOf(lv);
  const lvls = LEVELS.slice(Math.max(0, i - 1), i + 2);
  return VOCAB.filter((v) => lvls.includes(v.level));
}

export function qKanjiReading(lv: Level, n: number): Question[] {
  const pool = vocabByLevel(lv).filter((v) => hasKanji(v.w) && v.w !== v.r);
  const near = nearPool(lv);
  return sample(pool, n).map((v) => {
    const close = near.filter((x) => x.r !== v.r && Math.abs(x.r.length - v.r.length) <= 1);
    const { options, answer } = withOptions(v.r, sample(close, 6).map((x) => x.r));
    return {
      id: `kr-${v.id}`,
      section: "vocab",
      kind: "漢字読み",
      kindMn: "Ханзын уншлага",
      level: lv,
      prompt: v.w,
      big: true,
      options,
      answer,
      explain: `${v.w}（${v.r}）— ${v.mn}`,
    };
  });
}

export function qOrthography(lv: Level, n: number): Question[] {
  const pool = vocabByLevel(lv).filter((v) => hasKanji(v.w) && v.w !== v.r);
  const near = nearPool(lv).filter((v) => hasKanji(v.w));
  return sample(pool, n).map((v) => {
    const close = near.filter((x) => x.w !== v.w && x.w.length === v.w.length);
    const fallback = near.filter((x) => x.w !== v.w);
    const { options, answer } = withOptions(v.w, [...sample(close, 4), ...sample(fallback, 4)].map((x) => x.w));
    return {
      id: `or-${v.id}`,
      section: "vocab",
      kind: "表記",
      kindMn: "Бичлэг (уншлага → ханз)",
      level: lv,
      prompt: v.r,
      big: true,
      options,
      answer,
      explain: `${v.r} → ${v.w} — ${v.mn}`,
    };
  });
}

export function qMeaning(lv: Level, n: number, pool?: VocabItem[]): Question[] {
  const src = pool ?? vocabByLevel(lv);
  const near = nearPool(lv);
  return sample(src, n).map((v) => {
    const { options, answer } = withOptions(v.mn, sample(near.filter((x) => x.id !== v.id), 6).map((x) => x.mn));
    return {
      id: `mn-${v.id}`,
      section: "vocab",
      kind: "語彙",
      kindMn: "Үгийн утга",
      level: v.level,
      prompt: v.w === v.r ? v.w : `${v.w}{${v.r}}`,
      big: true,
      options,
      answer,
      explain: `${v.w}（${v.r}）— ${v.mn} · ${v.en}`,
    };
  });
}

export function qGrammar(lv: Level, n: number): Question[] {
  return sample(grammarByLevel(lv), n).map((g) => {
    const ans = target(g.q.s);
    const { options, answer } = withOptions(ans, g.q.d);
    return {
      id: `gq-${g.id}`,
      section: "grammar",
      kind: "文法形式",
      kindMn: "Дүрмийн хэлбэр",
      level: lv,
      prompt: blank(g.q.s),
      options,
      answer,
      explain: `${g.p} — ${g.mn}`,
    };
  });
}

export function qReading(lv: Level): Question[] {
  const p = passagesByLevel(lv)[0];
  if (!p) return [];
  return p.qs.map((q, i) => {
    const correct = q.opts[q.ans];
    const options = shuffle(q.opts);
    return {
      id: `rd-${p.id}-${i}`,
      section: "reading",
      kind: "読解",
      kindMn: "Уншиж ойлгох",
      level: lv,
      prompt: q.q,
      passage: { title: p.title, text: p.text },
      options,
      answer: options.indexOf(correct),
      explain: q.why,
    };
  });
}

export function qListening(lv: Level, n: number): Question[] {
  const i = LEVELS.indexOf(lv);
  const lvls = LEVELS.slice(Math.max(0, i - 1), i + 1);
  const pool = GRAMMAR.filter((g) => lvls.includes(g.level)).flatMap((g) =>
    g.ex.map(([jp, mn], k) => ({ id: `${g.id}-${k}`, jp, mn, level: g.level })),
  );
  return sample(pool, n).map((e) => {
    const { options, answer } = withOptions(e.mn, sample(pool.filter((x) => x.id !== e.id), 5).map((x) => x.mn));
    return {
      id: `ls-${e.id}`,
      section: "listening",
      kind: "聴解",
      kindMn: "Сонсоод утгыг ол",
      level: lv,
      prompt: "",
      speak: plain(e.jp),
      options,
      answer,
      explain: `${plain(e.jp)} — ${e.mn}`,
    };
  });
}

export function buildMock(lv: Level): Question[] {
  return [
    ...qKanjiReading(lv, 4),
    ...qOrthography(lv, 3),
    ...qMeaning(lv, 3),
    ...qGrammar(lv, 6),
    ...qReading(lv),
    ...qListening(lv, 4),
  ];
}

export function buildPlacement(): Question[] {
  return LEVELS.flatMap((lv) => [...qKanjiReading(lv, 2), ...qGrammar(lv, 1)]);
}

export interface Scored {
  scaled: number[];
  total: number;
  passed: boolean;
  sectionPass: boolean[];
  correct: number;
  bySection: Record<Section, { c: number; n: number }>;
}

export function scoreExam(lv: Level, qs: Question[], answers: (number | null)[]): Scored {
  const by: Record<Section, { c: number; n: number }> = {
    vocab: { c: 0, n: 0 },
    grammar: { c: 0, n: 0 },
    reading: { c: 0, n: 0 },
    listening: { c: 0, n: 0 },
  };
  qs.forEach((q, i) => {
    by[q.section].n++;
    if (answers[i] === q.answer) by[q.section].c++;
  });
  const meta = LEVEL_META[lv];
  const r = (c: number, n: number, max: number) => (n ? Math.round((c / n) * max) : 0);
  let scaled: number[];
  if (meta.sections.length === 2) {
    const c = by.vocab.c + by.grammar.c + by.reading.c;
    const n = by.vocab.n + by.grammar.n + by.reading.n;
    scaled = [r(c, n, 120), r(by.listening.c, by.listening.n, 60)];
  } else {
    scaled = [
      r(by.vocab.c + by.grammar.c, by.vocab.n + by.grammar.n, 60),
      r(by.reading.c, by.reading.n, 60),
      r(by.listening.c, by.listening.n, 60),
    ];
  }
  const total = scaled.reduce((a, b) => a + b, 0);
  const sectionPass = scaled.map((s, i) => s >= meta.sections[i].min);
  const correct = qs.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  return { scaled, total, passed: total >= meta.passTotal && sectionPass.every(Boolean), sectionPass, correct, bySection: by };
}

export function placementResult(qs: Question[], answers: (number | null)[]): Level | "zero" {
  let best: Level | "zero" = "zero";
  for (const lv of LEVELS) {
    const idx = qs.map((q, i) => (q.level === lv ? i : -1)).filter((i) => i >= 0);
    const c = idx.filter((i) => answers[i] === qs[i].answer).length;
    if (idx.length && c / idx.length >= 0.66) best = lv;
    else break;
  }
  return best;
}
