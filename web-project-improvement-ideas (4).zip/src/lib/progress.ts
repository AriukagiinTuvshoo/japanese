import { LEVELS, type Level } from "../data/levels";
import { vocabByLevel } from "../data/vocab";
import { kanjiByLevel } from "../data/kanji";
import { grammarByLevel } from "../data/grammar";
import { passagesByLevel } from "../data/reading";
import { isLearned } from "./srs";
import type { State } from "./store";

export interface LevelStats {
  level: Level;
  vocab: [number, number];
  kanji: [number, number];
  grammar: [number, number];
  reading: [number, number];
  bestMock: number | null;
  passedMock: boolean;
  pct: number;
}

export function levelStats(s: State, lv: Level): LevelStats {
  const v = vocabByLevel(lv);
  const k = kanjiByLevel(lv);
  const g = grammarByLevel(lv);
  const r = passagesByLevel(lv);
  const vocab: [number, number] = [v.filter((x) => isLearned(s.srs[x.id])).length, v.length];
  const kanji: [number, number] = [k.filter((x) => isLearned(s.srs[x.id])).length, k.length];
  const grammar: [number, number] = [g.filter((x) => s.grammarDone.includes(x.id)).length, g.length];
  const reading: [number, number] = [r.filter((x) => s.readingDone.includes(x.id)).length, r.length];
  const mocks = s.exams.filter((e) => e.level === lv);
  const bestMock = mocks.length ? Math.max(...mocks.map((m) => m.total)) : null;
  const passedMock = mocks.some((m) => m.passed);
  const f = (p: [number, number]) => (p[1] ? p[0] / p[1] : 0);
  const pct = f(vocab) * 0.3 + f(kanji) * 0.2 + f(grammar) * 0.25 + f(reading) * 0.1 + (passedMock ? 0.15 : bestMock ? (bestMock / 180) * 0.15 : 0);
  return { level: lv, vocab, kanji, grammar, reading, bestMock, passedMock, pct };
}

/** Одоо гол анхаарах түвшин */
export function focusLevel(s: State): Level {
  const cur = s.profile.current;
  if (cur === "zero") return "N5";
  for (const lv of LEVELS) {
    if (LEVELS.indexOf(lv) < LEVELS.indexOf(cur)) continue;
    if (levelStats(s, lv).pct < 0.85) return lv;
  }
  return "N1";
}

export function heatmap(s: State, weeks = 16) {
  const days: { key: string; min: number; xp: number; date: Date }[] = [];
  const end = new Date();
  const start = new Date(end);
  start.setDate(end.getDate() - (weeks * 7 - 1) - ((end.getDay() + 6) % 7 === 6 ? 0 : 0));
  // эхлэлийг даваа гараг руу тааруулах
  while (start.getDay() !== 1) start.setDate(start.getDate() - 1);
  const d = new Date(start);
  while (d <= end) {
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const a = s.activity[key];
    days.push({ key, min: a?.min ?? 0, xp: a?.xp ?? 0, date: new Date(d) });
    d.setDate(d.getDate() + 1);
  }
  return days;
}
