import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Level } from "../data/levels";
import { schedule, type Card, type Grade } from "./srs";
import { todayKey } from "./text";

export interface ExamRecord {
  level: Level;
  at: number;
  total: number;
  sections: number[];
  passed: boolean;
  correct: number;
  count: number;
}

export interface Mistake {
  id: string;
  kind: string;
  level: Level;
  prompt: string;
  answer: string;
  given: string;
  note?: string;
  at: number;
  count: number;
}

export interface Profile {
  name: string;
  current: Level | "zero";
  target: Level;
  examDate: string;
  dailyGoal: number;
  newPerDay: number;
  onboarded: boolean;
  furigana: boolean;
  rate: number;
}

export interface State {
  v: 1;
  profile: Profile;
  srs: Record<string, Card>;
  grammarDone: string[];
  readingDone: string[];
  kanaBest: number;
  exams: ExamRecord[];
  placement?: { level: Level | "zero"; at: number };
  mistakes: Mistake[];
  activity: Record<string, { xp: number; min: number; newCards: number }>;
  xp: number;
}

const KEY = "nihongo-dojo-v1";

const DEFAULT: State = {
  v: 1,
  profile: {
    name: "",
    current: "zero",
    target: "N5",
    examDate: "",
    dailyGoal: 20,
    newPerDay: 10,
    onboarded: false,
    furigana: true,
    rate: 0.9,
  },
  srs: {},
  grammarDone: [],
  readingDone: [],
  kanaBest: 0,
  exams: [],
  mistakes: [],
  activity: {},
  xp: 0,
};

function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT;
    const s = JSON.parse(raw) as Partial<State>;
    return { ...DEFAULT, ...s, profile: { ...DEFAULT.profile, ...(s.profile ?? {}) } };
  } catch {
    return DEFAULT;
  }
}

interface Actions {
  setProfile: (p: Partial<Profile>) => void;
  grade: (id: string, g: Grade, isNew?: boolean) => void;
  addXP: (n: number) => void;
  toggleGrammar: (id: string, on?: boolean) => void;
  markReading: (id: string) => void;
  setKanaBest: (n: number) => void;
  recordExam: (r: ExamRecord) => void;
  setPlacement: (lv: Level | "zero") => void;
  addMistakes: (m: Omit<Mistake, "at" | "count">[]) => void;
  resolveMistake: (id: string) => void;
  clearMistakes: () => void;
  importState: (json: string) => boolean;
  reset: () => void;
}

interface Ctx {
  state: State;
  actions: Actions;
  today: { xp: number; min: number; newCards: number };
  streak: number;
}

const StoreCtx = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(load);
  const lastAct = useRef(Date.now());

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* хадгалах боломжгүй */
    }
  }, [state]);

  const bumpToday = useCallback((patch: Partial<{ xp: number; min: number; newCards: number }>) => {
    const k = todayKey();
    setState((s) => {
      const cur = s.activity[k] ?? { xp: 0, min: 0, newCards: 0 };
      return {
        ...s,
        xp: s.xp + (patch.xp ?? 0),
        activity: {
          ...s.activity,
          [k]: {
            xp: cur.xp + (patch.xp ?? 0),
            min: cur.min + (patch.min ?? 0),
            newCards: cur.newCards + (patch.newCards ?? 0),
          },
        },
      };
    });
  }, []);

  /* идэвхтэй минутыг тоолох */
  useEffect(() => {
    const mark = () => (lastAct.current = Date.now());
    const evs = ["pointerdown", "keydown", "scroll", "touchstart"];
    evs.forEach((e) => window.addEventListener(e, mark, { passive: true }));
    const t = window.setInterval(() => {
      if (document.visibilityState === "visible" && Date.now() - lastAct.current < 90_000) {
        bumpToday({ min: 1 });
      }
    }, 60_000);
    return () => {
      evs.forEach((e) => window.removeEventListener(e, mark));
      window.clearInterval(t);
    };
  }, [bumpToday]);

  const actions = useMemo<Actions>(
    () => ({
      setProfile: (p) => setState((s) => ({ ...s, profile: { ...s.profile, ...p } })),
      grade: (id, g, isNew) => {
        setState((s) => ({ ...s, srs: { ...s.srs, [id]: schedule(s.srs[id], g) } }));
        bumpToday({ xp: g === 0 ? 1 : 3, newCards: isNew ? 1 : 0 });
      },
      addXP: (n) => bumpToday({ xp: n }),
      toggleGrammar: (id, on) =>
        setState((s) => {
          const has = s.grammarDone.includes(id);
          const want = on ?? !has;
          if (want === has) return s;
          return { ...s, grammarDone: want ? [...s.grammarDone, id] : s.grammarDone.filter((x) => x !== id) };
        }),
      markReading: (id) =>
        setState((s) => (s.readingDone.includes(id) ? s : { ...s, readingDone: [...s.readingDone, id] })),
      setKanaBest: (n) => setState((s) => ({ ...s, kanaBest: Math.max(s.kanaBest, n) })),
      recordExam: (r) => setState((s) => ({ ...s, exams: [r, ...s.exams].slice(0, 50) })),
      setPlacement: (lv) =>
        setState((s) => ({
          ...s,
          placement: { level: lv, at: Date.now() },
          profile: { ...s.profile, current: lv },
        })),
      addMistakes: (list) =>
        setState((s) => {
          const map = new Map(s.mistakes.map((m) => [m.id, m]));
          list.forEach((m) => {
            const prev = map.get(m.id);
            map.set(m.id, { ...m, at: Date.now(), count: (prev?.count ?? 0) + 1 });
          });
          return { ...s, mistakes: [...map.values()].sort((a, b) => b.at - a.at).slice(0, 300) };
        }),
      resolveMistake: (id) => setState((s) => ({ ...s, mistakes: s.mistakes.filter((m) => m.id !== id) })),
      clearMistakes: () => setState((s) => ({ ...s, mistakes: [] })),
      importState: (json) => {
        try {
          const parsed = JSON.parse(json) as State;
          if (!parsed || parsed.v !== 1) return false;
          setState({ ...DEFAULT, ...parsed, profile: { ...DEFAULT.profile, ...parsed.profile } });
          return true;
        } catch {
          return false;
        }
      },
      reset: () => setState(DEFAULT),
    }),
    [bumpToday],
  );

  const today = state.activity[todayKey()] ?? { xp: 0, min: 0, newCards: 0 };

  const streak = useMemo(() => {
    let n = 0;
    const d = new Date();
    if (!(state.activity[todayKey(d)]?.xp > 0)) d.setDate(d.getDate() - 1);
    while (state.activity[todayKey(d)]?.xp > 0) {
      n++;
      d.setDate(d.getDate() - 1);
    }
    return n;
  }, [state.activity]);

  const value = useMemo(() => ({ state, actions, today, streak }), [state, actions, today, streak]);
  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export function useStore() {
  const c = useContext(StoreCtx);
  if (!c) throw new Error("StoreProvider алга");
  return c;
}
