/*
 * SM-2 алгоритмд суурилсан хялбаршуулсан давталтын систем.
 * 0 = Дахин, 1 = Хэцүү, 2 = Сайн, 3 = Амархан
 */
export type Grade = 0 | 1 | 2 | 3;

export interface Card {
  ease: number;
  ivl: number;
  due: number;
  reps: number;
  lapses: number;
  seen: number;
}

const DAY = 864e5;
const MIN = 6e4;

export function schedule(prev: Card | undefined, g: Grade, now = Date.now()): Card {
  const c: Card = prev ?? { ease: 2.5, ivl: 0, due: now, reps: 0, lapses: 0, seen: 0 };
  let { ease, ivl, reps, lapses } = c;

  if (g === 0) {
    return {
      ease: Math.max(1.3, ease - 0.2),
      ivl: 0,
      due: now + 10 * MIN,
      reps: 0,
      lapses: lapses + (reps > 0 ? 1 : 0),
      seen: c.seen + 1,
    };
  }

  if (reps === 0) ivl = g === 1 ? 0.5 : g === 2 ? 1 : 4;
  else if (reps === 1) ivl = g === 1 ? 2 : g === 2 ? 3 : 7;
  else ivl = Math.max(1, ivl * (g === 1 ? 1.2 : g === 2 ? ease : ease * 1.35));

  ease = Math.min(3.0, Math.max(1.3, ease + (g === 1 ? -0.15 : g === 3 ? 0.15 : 0)));
  reps += 1;

  return { ease, ivl, due: now + ivl * DAY, reps, lapses, seen: c.seen + 1 };
}

export function previewLabel(prev: Card | undefined, g: Grade) {
  const next = schedule(prev, g, 0);
  const ms = next.due;
  if (ms < DAY) return `${Math.max(1, Math.round(ms / MIN))} мин`;
  const d = ms / DAY;
  if (d < 30) return `${Math.round(d)} өдөр`;
  if (d < 365) return `${Math.round(d / 30)} сар`;
  return `${(d / 365).toFixed(1)} жил`;
}

export const isLearned = (c?: Card) => !!c && c.reps >= 1;
export const isMastered = (c?: Card) => !!c && c.ivl >= 21;
export const isDue = (c?: Card, now = Date.now()) => !!c && c.due <= now;
