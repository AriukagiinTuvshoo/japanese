export interface Seg {
  t: string;
  r?: string;
  hl: boolean;
}

const TOKEN = /\[|\]|([\u3400-\u9fff\u3005\u3006\u30f6]+)\{([^}]+)\}/g;

/** 漢字{かな} ба [онцлох] тэмдэглэгээг задлана */
export function parseRuby(src: string): Seg[] {
  const out: Seg[] = [];
  let hl = false;
  let last = 0;
  let m: RegExpExecArray | null;
  TOKEN.lastIndex = 0;
  while ((m = TOKEN.exec(src)) !== null) {
    if (m.index > last) out.push({ t: src.slice(last, m.index), hl });
    if (m[0] === "[") hl = true;
    else if (m[0] === "]") hl = false;
    else out.push({ t: m[1], r: m[2], hl });
    last = m.index + m[0].length;
  }
  if (last < src.length) out.push({ t: src.slice(last), hl });
  return out;
}

/** Фуригана, хаалтгүй цэвэр текст */
export const plain = (s: string) => s.replace(/\{[^}]*\}/g, "").replace(/[[\]]/g, "");

/** Ханзыг уншлагаар сольсон кана текст */
export const kanaOnly = (s: string) =>
  s.replace(/([\u3400-\u9fff\u3005\u3006\u30f6]+)\{([^}]+)\}/g, "$2").replace(/[[\]]/g, "");

/** [ ] доторх хэсэг */
export function target(s: string) {
  const m = s.match(/\[([^\]]+)\]/);
  return m ? plain(m[1]) : "";
}

/** [ ] хэсгийг хоосон зайгаар солих */
export const blank = (s: string, fill = "＿＿＿") => s.replace(/\[[^\]]+\]/, `[${fill}]`);

export function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function sample<T>(arr: T[], n: number, exclude?: (x: T) => boolean): T[] {
  return shuffle(exclude ? arr.filter((x) => !exclude(x)) : arr).slice(0, n);
}

export const todayKey = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export const greetingJp = () => {
  const h = new Date().getHours();
  if (h < 11) return { jp: "おはようございます", mn: "Өглөөний мэнд" };
  if (h < 18) return { jp: "こんにちは", mn: "Өдрийн мэнд" };
  return { jp: "こんばんは", mn: "Оройн мэнд" };
};
