let cached: SpeechSynthesisVoice | null | undefined;

function pickVoice(): SpeechSynthesisVoice | null {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return null;
  const voices = window.speechSynthesis.getVoices();
  if (!voices.length) return null;
  const ja = voices.filter((v) => v.lang.toLowerCase().startsWith("ja"));
  const preferred =
    ja.find((v) => /google|kyoko|o-ren|nanami|haruka|ayumi/i.test(v.name)) ?? ja[0] ?? null;
  cached = preferred;
  return preferred;
}

if (typeof window !== "undefined" && "speechSynthesis" in window) {
  window.speechSynthesis.onvoiceschanged = () => {
    cached = undefined;
    pickVoice();
  };
}

export const canSpeak = () => typeof window !== "undefined" && "speechSynthesis" in window;

export function hasJapaneseVoice() {
  if (!canSpeak()) return false;
  return (cached ?? pickVoice()) !== null;
}

export function speak(text: string, rate = 0.9, onEnd?: () => void) {
  if (!canSpeak() || !text) return false;
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "ja-JP";
  u.rate = rate;
  const v = cached ?? pickVoice();
  if (v) u.voice = v;
  if (onEnd) u.onend = onEnd;
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(u);
  return true;
}

export const stopSpeaking = () => canSpeak() && window.speechSynthesis.cancel();
