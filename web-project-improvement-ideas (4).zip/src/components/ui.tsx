import { useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import { LEVELS, LEVEL_META, type Level, type Tone } from "../data/levels";
import { parseRuby } from "../lib/text";
import { canSpeak, speak } from "../lib/speech";
import { useStore } from "../lib/store";
import { cn } from "../utils/cn";

/* ------------------------------------------------------------------ */
/*  Өнгөний тон — Tailwind-ийн литерал класс                           */
/* ------------------------------------------------------------------ */
export const TONE: Record<Tone, { soft: string; text: string; solid: string; ring: string; bar: string; hex: string }> = {
  matcha: { soft: "bg-matcha-50", text: "text-matcha-600", solid: "bg-matcha-500 text-white", ring: "border-matcha-400", bar: "bg-matcha-500", hex: "#688c45" },
  ai: { soft: "bg-ai-50", text: "text-ai-500", solid: "bg-ai-500 text-white", ring: "border-ai-400", bar: "bg-ai-500", hex: "#2f5385" },
  kin: { soft: "bg-kin-50", text: "text-kin-600", solid: "bg-kin-500 text-white", ring: "border-kin-400", bar: "bg-kin-500", hex: "#b88a2d" },
  shu: { soft: "bg-shu-50", text: "text-shu-600", solid: "bg-shu-500 text-white", ring: "border-shu-400", bar: "bg-shu-500", hex: "#cc4630" },
  murasaki: { soft: "bg-murasaki-50", text: "text-murasaki-500", solid: "bg-murasaki-500 text-white", ring: "border-murasaki-400", bar: "bg-murasaki-500", hex: "#6f4b89" },
};
export const levelTone = (lv: Level) => TONE[LEVEL_META[lv].tone];

/* ------------------------------------------------------------------ */
export function Ruby({
  text,
  furigana,
  className,
  hlClass = "text-shu-600 underline decoration-shu-400/60 decoration-2 underline-offset-[6px]",
}: {
  text: string;
  furigana?: boolean;
  className?: string;
  hlClass?: string;
}) {
  const { state } = useStore();
  const show = furigana ?? state.profile.furigana;
  return (
    <span className={cn("font-jp", className)} lang="ja">
      {parseRuby(text).map((s, i) => {
        const body = s.r && show ? (
          <ruby>
            {s.t}
            <rt>{s.r}</rt>
          </ruby>
        ) : (
          s.t
        );
        return s.hl ? (
          <span key={i} className={hlClass}>
            {body}
          </span>
        ) : (
          <span key={i}>{body}</span>
        );
      })}
    </span>
  );
}

/* ------------------------------------------------------------------ */
export function SpeakButton({
  text,
  className,
  size = "md",
  label,
}: {
  text: string;
  className?: string;
  size?: "sm" | "md" | "lg";
  label?: string;
}) {
  const { state } = useStore();
  const [on, setOn] = useState(false);
  if (!canSpeak()) return null;
  const dims = size === "sm" ? "h-7 w-7" : size === "lg" ? "h-12 w-12" : "h-9 w-9";
  return (
    <button
      type="button"
      aria-label={label ?? "Сонсох"}
      title={label ?? "Сонсох"}
      onClick={(e) => {
        e.stopPropagation();
        setOn(true);
        speak(text, state.profile.rate, () => setOn(false));
        window.setTimeout(() => setOn(false), 4000);
      }}
      className={cn(
        "grid shrink-0 place-items-center rounded-full border transition-all duration-200 active:scale-90",
        on
          ? "border-shu-500 bg-shu-500 text-white"
          : "border-sumi-900/10 bg-white/70 text-sumi-700 hover:border-shu-400 hover:text-shu-600",
        dims,
        className,
      )}
    >
      <svg viewBox="0 0 24 24" className={size === "lg" ? "h-5 w-5" : "h-4 w-4"} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M11 5 6 9H3v6h3l5 4V5Z" fill="currentColor" stroke="none" />
        <path d="M15.5 8.5a5 5 0 0 1 0 7" className={on ? "animate-pulse" : ""} />
        <path d="M18.5 5.5a9 9 0 0 1 0 13" className={on ? "animate-pulse" : ""} />
      </svg>
    </button>
  );
}

/* ------------------------------------------------------------------ */
type BtnVariant = "primary" | "ink" | "ghost" | "outline" | "soft";
export function Button({
  variant = "primary",
  size = "md",
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; size?: "sm" | "md" | "lg" }) {
  const v: Record<BtnVariant, string> = {
    primary: "bg-shu-500 text-white shadow-[0_8px_22px_-10px_rgba(204,70,48,0.8)] hover:bg-shu-600",
    ink: "bg-sumi-900 text-washi-50 hover:bg-sumi-800",
    ghost: "text-sumi-700 hover:bg-sumi-900/5",
    outline: "border border-sumi-900/15 bg-white/60 text-sumi-800 hover:border-sumi-900/35 hover:bg-white",
    soft: "bg-washi-200 text-sumi-800 hover:bg-washi-300",
  };
  const s = size === "sm" ? "h-9 px-3.5 text-[13px]" : size === "lg" ? "h-13 px-7 text-[15px]" : "h-11 px-5 text-[14px]";
  return (
    <button
      {...rest}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl font-bold transition-all duration-200 active:scale-[0.97] disabled:pointer-events-none disabled:opacity-40",
        v[variant],
        s,
        className,
      )}
    >
      {children}
    </button>
  );
}

/* ------------------------------------------------------------------ */
export function Card({ className, children, onClick }: { className?: string; children: ReactNode; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "rounded-2xl border border-sumi-900/[0.08] bg-washi-50/90 shadow-[0_1px_0_rgba(255,255,255,0.8)_inset,0_10px_30px_-24px_rgba(28,27,24,0.5)]",
        className,
      )}
    >
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ */
export function LevelTabs({
  value,
  onChange,
  meta,
}: {
  value: Level;
  onChange: (l: Level) => void;
  meta?: (l: Level) => string;
}) {
  return (
    <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
      {LEVELS.map((lv) => {
        const t = levelTone(lv);
        const on = lv === value;
        return (
          <button
            key={lv}
            onClick={() => onChange(lv)}
            className={cn(
              "group flex shrink-0 items-center gap-2 rounded-xl border px-3.5 py-2 transition-all duration-200",
              on ? cn(t.solid, "border-transparent shadow-md") : "border-sumi-900/10 bg-white/60 text-sumi-700 hover:border-sumi-900/25",
            )}
          >
            <span className="font-mono text-[13px] font-semibold">{lv}</span>
            <span className={cn("text-[11.5px] font-semibold", on ? "text-white/80" : "text-sumi-500")}>
              {meta ? meta(lv) : LEVEL_META[lv].name}
            </span>
          </button>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
export function Ring({
  value,
  size = 72,
  stroke = 7,
  color = "#cc4630",
  track = "rgba(28,27,24,0.08)",
  children,
}: {
  value: number;
  size?: number;
  stroke?: number;
  color?: string;
  track?: string;
  children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(1, value));
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - v)}
          style={{ transition: "stroke-dashoffset .8s cubic-bezier(.22,1,.36,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

export function Bar({ value, className, barClass = "bg-shu-500" }: { value: number; className?: string; barClass?: string }) {
  return (
    <div className={cn("h-1.5 w-full overflow-hidden rounded-full bg-sumi-900/[0.07]", className)}>
      <div
        className={cn("h-full rounded-full transition-[width] duration-700 ease-out", barClass)}
        style={{ width: `${Math.max(0, Math.min(1, value)) * 100}%` }}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
export function PageHeader({
  kanji,
  eyebrow,
  title,
  sub,
  right,
}: {
  kanji: string;
  eyebrow: string;
  title: string;
  sub?: string;
  right?: ReactNode;
}) {
  return (
    <header className="relative mb-7 flex flex-col gap-5 sm:mb-9 sm:flex-row sm:items-end sm:justify-between">
      <div className="flex items-start gap-4">
        <span className="hanko grid h-14 w-14 shrink-0 place-items-center rounded-xl bg-shu-500 text-[1.9rem] font-black text-washi-50 shadow-[0_10px_24px_-12px_rgba(204,70,48,0.9)]">
          {kanji}
        </span>
        <div>
          <p className="font-mono text-[10.5px] font-semibold uppercase tracking-[0.24em] text-shu-600">{eyebrow}</p>
          <h1 className="mt-1 text-[clamp(1.6rem,3.4vw,2.35rem)] font-extrabold leading-[1.08] tracking-[-0.02em] text-sumi-900">
            {title}
          </h1>
          {sub && <p className="mt-2 max-w-2xl text-[14.5px] leading-relaxed text-sumi-600">{sub}</p>}
        </div>
      </div>
      {right && <div className="flex shrink-0 flex-wrap items-center gap-2">{right}</div>}
    </header>
  );
}

export function Chip({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold", className)}>
      {children}
    </span>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { id: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="inline-flex rounded-xl border border-sumi-900/10 bg-white/60 p-1">
      {options.map((o) => (
        <button
          key={o.id}
          onClick={() => onChange(o.id)}
          className={cn(
            "rounded-lg px-3.5 py-1.5 text-[12.5px] font-bold transition-all duration-200",
            value === o.id ? "bg-sumi-900 text-washi-50 shadow" : "text-sumi-600 hover:text-sumi-900",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

/* Олон сонголттой хариултын товч */
export function OptionButton({
  idx,
  state,
  onClick,
  children,
  disabled,
}: {
  idx: number;
  state: "idle" | "picked" | "correct" | "wrong" | "dim";
  onClick: () => void;
  children: ReactNode;
  disabled?: boolean;
}) {
  const styles = {
    idle: "border-sumi-900/12 bg-white/70 hover:-translate-y-0.5 hover:border-sumi-900/30 hover:bg-white",
    picked: "border-ai-500 bg-ai-50 ring-2 ring-ai-500/20",
    correct: "border-matcha-500 bg-matcha-50 ring-2 ring-matcha-500/25",
    wrong: "shake border-shu-500 bg-shu-50 ring-2 ring-shu-500/20",
    dim: "border-sumi-900/8 bg-white/40 opacity-55",
  }[state];
  const badge = {
    idle: "bg-washi-200 text-sumi-600",
    picked: "bg-ai-500 text-white",
    correct: "bg-matcha-500 text-white",
    wrong: "bg-shu-500 text-white",
    dim: "bg-washi-200 text-sumi-400",
  }[state];
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3 rounded-xl border px-4 py-3.5 text-left transition-all duration-200 disabled:cursor-default",
        styles,
      )}
    >
      <span className={cn("grid h-7 w-7 shrink-0 place-items-center rounded-lg font-mono text-[12px] font-bold", badge)}>
        {state === "correct" ? "✓" : state === "wrong" ? "✕" : idx + 1}
      </span>
      <span className="min-w-0 flex-1 text-[15px] font-semibold text-sumi-800">{children}</span>
    </button>
  );
}

export function Empty({ kanji, title, sub, action }: { kanji: string; title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-dashed border-sumi-900/15 px-6 py-14 text-center">
      <span className="font-mincho text-[3.2rem] font-black leading-none text-washi-400">{kanji}</span>
      <p className="mt-4 text-[17px] font-extrabold text-sumi-800">{title}</p>
      {sub && <p className="mt-1.5 max-w-sm text-[13.5px] text-sumi-500">{sub}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}
