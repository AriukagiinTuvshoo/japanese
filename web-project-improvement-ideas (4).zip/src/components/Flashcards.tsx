import { useCallback, useEffect, useState, type ReactNode } from "react";
import { useStore } from "../lib/store";
import { previewLabel, type Grade } from "../lib/srs";
import { speak } from "../lib/speech";
import { Bar, Button, Card } from "./ui";
import { cn } from "../utils/cn";

export interface FlashItem {
  id: string;
  front: ReactNode;
  back: ReactNode;
  say?: string;
  isNew: boolean;
}

const GRADES: { g: Grade; label: string; cls: string; key: string }[] = [
  { g: 0, label: "Дахин", cls: "border-shu-400 text-shu-600 hover:bg-shu-50", key: "1" },
  { g: 1, label: "Хэцүү", cls: "border-kin-400 text-kin-600 hover:bg-kin-50", key: "2" },
  { g: 2, label: "Сайн", cls: "border-matcha-400 text-matcha-600 hover:bg-matcha-50", key: "3" },
  { g: 3, label: "Амархан", cls: "border-ai-400 text-ai-500 hover:bg-ai-50", key: "4" },
];

export default function Flashcards({ items, onExit, title }: { items: FlashItem[]; onExit: () => void; title: string }) {
  const { state, actions } = useStore();
  const [queue, setQueue] = useState<FlashItem[]>(items);
  const [shown, setShown] = useState(false);
  const [done, setDone] = useState(0);
  const [tally, setTally] = useState<[number, number, number, number]>([0, 0, 0, 0]);
  const total = items.length;
  const cur = queue[0];

  useEffect(() => {
    if (cur?.say && state.profile.rate) speak(cur.say, state.profile.rate);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cur?.id]);

  const grade = useCallback(
    (g: Grade) => {
      if (!cur) return;
      actions.grade(cur.id, g, cur.isNew);
      setTally((t) => {
        const n = [...t] as [number, number, number, number];
        n[g]++;
        return n;
      });
      setShown(false);
      if (g !== 0) setDone((d) => d + 1);
      setQueue((q) => {
        const [head, ...rest] = q;
        if (g === 0) {
          const pos = Math.min(rest.length, 3);
          return [...rest.slice(0, pos), { ...head, isNew: false }, ...rest.slice(pos)];
        }
        return rest;
      });
    },
    [cur, actions],
  );

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === "INPUT") return;
      if (e.code === "Space" || e.key === "Enter") {
        e.preventDefault();
        if (!shown) setShown(true);
        else grade(2);
      }
      if (shown && ["1", "2", "3", "4"].includes(e.key)) grade((Number(e.key) - 1) as Grade);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [shown, grade]);

  if (!cur) {
    const acc = tally[1] + tally[2] + tally[3];
    return (
      <Card className="mx-auto max-w-xl animate-pop p-8 text-center sm:p-10">
        <p className="font-mincho text-[3.6rem] font-black leading-none text-matcha-500">完了</p>
        <h2 className="mt-4 text-[1.5rem] font-extrabold">Сесс дууслаа!</h2>
        <p className="mt-2 text-[14px] text-sumi-600">
          {total} карт давтлаа · {acc} зөв / {tally[0]} дахин
        </p>
        <div className="mt-6 grid grid-cols-4 gap-2">
          {GRADES.map((g, i) => (
            <div key={g.g} className="rounded-xl border border-sumi-900/10 bg-white/70 py-3">
              <p className="text-[1.3rem] font-extrabold tabnum">{tally[i]}</p>
              <p className="text-[11px] font-bold text-sumi-500">{g.label}</p>
            </div>
          ))}
        </div>
        <Button className="mt-7 w-full" onClick={onExit}>
          Буцах
        </Button>
      </Card>
    );
  }

  const card = state.srs[cur.id];

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-4 flex items-center gap-3">
        <button onClick={onExit} className="grid h-9 w-9 place-items-center rounded-xl border border-sumi-900/10 bg-white/70 text-sumi-600 hover:text-sumi-900" aria-label="Гарах">
          ✕
        </button>
        <div className="flex-1">
          <div className="mb-1.5 flex justify-between text-[12px] font-bold text-sumi-500">
            <span>{title}</span>
            <span className="tabnum">
              {done}/{total}
            </span>
          </div>
          <Bar value={done / Math.max(1, total)} />
        </div>
      </div>

      <Card className="relative overflow-hidden">
        <div className="seigaiha pointer-events-none absolute inset-x-0 top-0 h-16 text-shu-500/[0.06]" />
        {cur.isNew && (
          <span className="absolute left-5 top-5 rounded-full bg-ai-50 px-2.5 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-ai-500">
            шинэ
          </span>
        )}
        <div key={cur.id} className="flip-in flex min-h-[260px] flex-col items-center justify-center px-6 pb-6 pt-12 text-center sm:min-h-[300px]">
          {cur.front}
          {cur.say && (
            <button
              onClick={() => speak(cur.say!, state.profile.rate)}
              className="mt-4 rounded-full border border-sumi-900/10 bg-white/70 px-3 py-1.5 text-[12px] font-bold text-sumi-600 hover:border-shu-400 hover:text-shu-600"
            >
              🔊 Дахин сонсох
            </button>
          )}
        </div>

        <div className={cn("grid transition-all duration-400", shown ? "grid-rows-[1fr]" : "grid-rows-[0fr]")}>
          <div className="overflow-hidden">
            <div className="border-t border-dashed border-sumi-900/15 px-6 py-6 text-center">{cur.back}</div>
          </div>
        </div>
      </Card>

      <div className="mt-4">
        {!shown ? (
          <Button size="lg" variant="ink" className="w-full" onClick={() => setShown(true)}>
            Хариуг харах <span className="font-mono text-[11px] opacity-60">Space</span>
          </Button>
        ) : (
          <div className="grid grid-cols-4 gap-2">
            {GRADES.map((g) => (
              <button
                key={g.g}
                onClick={() => grade(g.g)}
                className={cn("flex flex-col items-center rounded-xl border-2 bg-white/80 py-3 transition-all active:scale-95", g.cls)}
              >
                <span className="text-[14px] font-extrabold">{g.label}</span>
                <span className="mt-0.5 font-mono text-[10.5px] opacity-75">{previewLabel(card, g.g)}</span>
                <span className="mt-1 hidden font-mono text-[9.5px] text-sumi-400 sm:block">[{g.key}]</span>
              </button>
            ))}
          </div>
        )}
      </div>
      <p className="mt-3 text-center text-[11.5px] text-sumi-500">
        Санасан бол «Сайн», бага зэрэг бодсон бол «Хэцүү». Систем давтах хугацааг автоматаар тооцоолно.
      </p>
    </div>
  );
}
