import { useEffect, useRef, useState, type ReactNode } from "react";
import { useStore } from "../lib/store";
import { cn } from "../utils/cn";
import { Ring } from "./ui";

export type Route =
  | "home"
  | "roadmap"
  | "kana"
  | "vocab"
  | "kanji"
  | "grammar"
  | "reading"
  | "listening"
  | "exam"
  | "plan"
  | "mistakes";

export const NAV: { id: Route; k: string; label: string; group: string }[] = [
  { id: "home", k: "家", label: "Нүүр самбар", group: "Эхлэл" },
  { id: "roadmap", k: "道", label: "Замын зураг", group: "Эхлэл" },
  { id: "plan", k: "計", label: "Миний төлөвлөгөө", group: "Эхлэл" },
  { id: "kana", k: "あ", label: "Хирагана · Катакана", group: "Суурь" },
  { id: "vocab", k: "語", label: "Үгийн сан", group: "Суралцах" },
  { id: "kanji", k: "漢", label: "Ханз", group: "Суралцах" },
  { id: "grammar", k: "文", label: "Дүрэм", group: "Суралцах" },
  { id: "reading", k: "読", label: "Уншлага", group: "Чадвар" },
  { id: "listening", k: "聴", label: "Сонсгол", group: "Чадвар" },
  { id: "exam", k: "試", label: "JLPT шалгалт", group: "Шалгалт" },
  { id: "mistakes", k: "誤", label: "Алдааны дэвтэр", group: "Шалгалт" },
];

const LEGACY: Record<string, Route> = { jlpt: "exam", learn: "vocab", progress: "home" };

export function useRoute(): [Route, (r: Route) => void] {
  const parse = (): Route => {
    const h = window.location.hash.replace(/^#\/?/, "");
    if (LEGACY[h]) return LEGACY[h];
    return (NAV.find((n) => n.id === h)?.id ?? "home") as Route;
  };
  const [r, setR] = useState<Route>(parse);
  useEffect(() => {
    const on = () => {
      setR(parse());
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    };
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return [r, (next) => (window.location.hash = `/${next}`)];
}

export default function Shell({ route, go, children }: { route: Route; go: (r: Route) => void; children: ReactNode }) {
  const { state, today, streak, actions } = useStore();
  const [menu, setMenu] = useState(false);
  const [settings, setSettings] = useState(false);
  const goalPct = today.min / Math.max(1, state.profile.dailyGoal);
  const dueCount = Object.values(state.srs).filter((c) => c.due <= Date.now()).length;

  const groups = Array.from(new Set(NAV.map((n) => n.group)));

  const SideNav = (
    <nav className="flex flex-col gap-5">
      {groups.map((g) => (
        <div key={g}>
          <p className="mb-1.5 px-3 font-mono text-[9.5px] font-semibold uppercase tracking-[0.26em] text-washi-500/70">{g}</p>
          <ul className="space-y-0.5">
            {NAV.filter((n) => n.group === g).map((n) => {
              const on = route === n.id;
              return (
                <li key={n.id}>
                  <button
                    onClick={() => {
                      go(n.id);
                      setMenu(false);
                    }}
                    className={cn(
                      "group relative flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-all duration-200",
                      on ? "bg-washi-50 text-sumi-900" : "text-washi-300 hover:bg-white/[0.06] hover:text-washi-50",
                    )}
                  >
                    <span
                      className={cn(
                        "grid h-8 w-8 shrink-0 place-items-center rounded-lg font-mincho text-[17px] font-bold transition-colors",
                        on ? "bg-shu-500 text-washi-50" : "bg-white/[0.06] text-washi-200 group-hover:bg-white/10",
                      )}
                    >
                      {n.k}
                    </span>
                    <span className="flex-1 text-[13.5px] font-bold">{n.label}</span>
                    {n.id === "vocab" && dueCount > 0 && (
                      <span className="rounded-full bg-shu-500 px-1.5 py-0.5 font-mono text-[10px] font-bold text-white tabnum">
                        {dueCount}
                      </span>
                    )}
                    {n.id === "mistakes" && state.mistakes.length > 0 && (
                      <span className={cn("rounded-full px-1.5 py-0.5 font-mono text-[10px] font-bold tabnum", on ? "bg-washi-200 text-sumi-700" : "bg-white/10 text-washi-200")}>
                        {state.mistakes.length}
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );

  const Brand = (
    <button onClick={() => go("home")} className="flex items-center gap-3 text-left">
      <span className="hanko grid h-11 w-11 place-items-center rounded-xl bg-shu-500 text-[1.45rem] font-black text-washi-50">道</span>
      <span className="leading-none">
        <span className="block text-[17px] font-extrabold tracking-tight text-washi-50">Nihongo Dōjō</span>
        <span className="mt-1.5 block font-jp text-[11px] font-medium tracking-[0.18em] text-washi-400">日本語道場 · N5→N1</span>
      </span>
    </button>
  );

  return (
    <div className="washi min-h-screen">
      {/* ---------- desktop sidebar ---------- */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[264px] flex-col overflow-y-auto bg-sumi-900 px-4 pb-5 pt-6 lg:flex">
        <div className="seigaiha pointer-events-none absolute inset-x-0 bottom-0 h-48 text-white/[0.035]" />
        <div className="relative px-2">{Brand}</div>

        <div className="relative mx-1 mt-6 flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.04] p-3">
          <Ring value={goalPct} size={50} stroke={5} color="#e0654c" track="rgba(255,255,255,0.08)">
            <span className="font-mono text-[11px] font-bold text-washi-50 tabnum">{Math.min(99, Math.round(goalPct * 100))}%</span>
          </Ring>
          <div className="min-w-0 flex-1">
            <p className="text-[12px] font-bold text-washi-100">Өнөөдөр {today.min}/{state.profile.dailyGoal} мин</p>
            <p className="mt-1 flex items-center gap-2 text-[11.5px] text-washi-400">
              <span>🔥 {streak} өдөр</span>
              <span className="h-1 w-1 rounded-full bg-washi-500" />
              <span className="tabnum">{state.xp} XP</span>
            </p>
          </div>
        </div>

        <div className="relative mt-6 flex-1">{SideNav}</div>

        <button
          onClick={() => setSettings(true)}
          className="relative mt-6 flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-bold text-washi-400 transition-colors hover:bg-white/[0.06] hover:text-washi-50"
        >
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-white/[0.06] font-mincho text-[16px]">設</span>
          Тохиргоо · Нөөцлөл
        </button>
      </aside>

      {/* ---------- mobile top bar ---------- */}
      <header className="sticky top-0 z-40 flex h-16 items-center gap-3 border-b border-sumi-900/10 bg-sumi-900 px-4 lg:hidden">
        {Brand}
        <div className="ml-auto flex items-center gap-2">
          <span className="rounded-full bg-white/10 px-2.5 py-1 text-[12px] font-bold text-washi-100">🔥 {streak}</span>
          <button
            onClick={() => setMenu(true)}
            aria-label="Цэс"
            className="grid h-10 w-10 place-items-center rounded-xl bg-white/10 text-washi-50"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M4 7h16M4 12h16M4 17h10" />
            </svg>
          </button>
        </div>
      </header>

      {/* ---------- mobile drawer ---------- */}
      <div
        className={cn("fixed inset-0 z-50 lg:hidden", menu ? "pointer-events-auto" : "pointer-events-none")}
        aria-hidden={!menu}
      >
        <div
          onClick={() => setMenu(false)}
          className={cn("absolute inset-0 bg-sumi-950/50 backdrop-blur-sm transition-opacity", menu ? "opacity-100" : "opacity-0")}
        />
        <div
          className={cn(
            "absolute inset-y-0 left-0 w-[84%] max-w-[320px] overflow-y-auto bg-sumi-900 px-4 pb-6 pt-5 transition-transform duration-300",
            menu ? "translate-x-0" : "-translate-x-full",
          )}
        >
          <div className="mb-6 flex items-center justify-between px-2">
            {Brand}
            <button onClick={() => setMenu(false)} className="grid h-9 w-9 place-items-center rounded-lg bg-white/10 text-washi-50" aria-label="Хаах">
              ✕
            </button>
          </div>
          {SideNav}
          <button
            onClick={() => {
              setMenu(false);
              setSettings(true);
            }}
            className="mt-6 w-full rounded-xl bg-white/[0.06] px-3 py-3 text-left text-[13px] font-bold text-washi-300"
          >
            設 Тохиргоо · Нөөцлөл
          </button>
        </div>
      </div>

      {/* ---------- content ---------- */}
      <main className="lg:pl-[264px]">
        <div key={route} className="mx-auto max-w-[1180px] animate-rise px-4 pb-28 pt-6 sm:px-7 sm:pt-9 lg:pb-16">
          {children}
        </div>
      </main>

      {/* ---------- mobile bottom tabs ---------- */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-sumi-900/10 bg-washi-50/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-lg lg:hidden">
        <div className="grid grid-cols-5">
          {(["home", "vocab", "grammar", "exam", "plan"] as Route[]).map((id) => {
            const n = NAV.find((x) => x.id === id)!;
            const on = route === id;
            return (
              <button key={id} onClick={() => go(id)} className="relative flex flex-col items-center gap-0.5 py-2.5">
                <span className={cn("font-mincho text-[19px] font-bold leading-none transition-colors", on ? "text-shu-500" : "text-sumi-500")}>{n.k}</span>
                <span className={cn("text-[10px] font-bold", on ? "text-sumi-900" : "text-sumi-500")}>
                  {({ home: "Нүүр", vocab: "Үг", grammar: "Дүрэм", exam: "Шалгалт", plan: "Төлөвлөгөө" } as Record<string, string>)[id]}
                </span>
                {on && <span className="absolute top-0 h-0.5 w-8 rounded-full bg-shu-500" />}
              </button>
            );
          })}
        </div>
      </nav>

      {settings && <Settings onClose={() => setSettings(false)} />}
      {!state.profile.onboarded && <Onboarding onDone={() => actions.setProfile({ onboarded: true })} go={go} />}
    </div>
  );
}

/* ------------------------------------------------------------------ */
function Modal({ children, onClose }: { children: ReactNode; onClose?: () => void }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose?.();
    window.addEventListener("keydown", k);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", k);
      document.body.style.overflow = "";
    };
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-[60] grid place-items-end bg-sumi-950/55 p-0 backdrop-blur-sm sm:place-items-center sm:p-6" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="washi max-h-[92vh] w-full animate-pop overflow-y-auto rounded-t-3xl border border-sumi-900/10 shadow-2xl sm:max-w-lg sm:rounded-3xl"
      >
        {children}
      </div>
    </div>
  );
}

function Onboarding({ onDone, go }: { onDone: () => void; go: (r: Route) => void }) {
  const { state, actions } = useStore();
  const [name, setName] = useState(state.profile.name);
  const [goal, setGoal] = useState(state.profile.dailyGoal);
  return (
    <Modal>
      <div className="relative overflow-hidden bg-sumi-900 px-7 pb-8 pt-9 text-washi-50">
        <div className="seigaiha pointer-events-none absolute inset-0 text-white/[0.05]" />
        <p className="relative font-jp text-[13px] tracking-[0.3em] text-washi-400">ようこそ</p>
        <h2 className="relative mt-2 text-[1.8rem] font-extrabold leading-tight">Тавтай морил, Nihongo Dōjō-д</h2>
        <p className="relative mt-3 text-[14px] leading-relaxed text-washi-300">
          Тэгээс эхэлсэн ч, N3 дээр гацсан ч — кана, SRS үгийн сан, ханз, дүрэм, уншлага, сонсгол, JLPT жишиг шалгалтаар алхам алхмаар ахина.
        </p>
      </div>
      <div className="space-y-5 px-7 py-7">
        <label className="block">
          <span className="text-[12.5px] font-bold text-sumi-700">Таны нэр</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Жишээ: Сараа"
            className="mt-1.5 h-12 w-full rounded-xl border border-sumi-900/15 bg-white px-4 text-[15px] font-semibold outline-none transition focus:border-shu-500 focus:ring-4 focus:ring-shu-500/10"
          />
        </label>
        <div>
          <span className="text-[12.5px] font-bold text-sumi-700">Өдөрт хэдэн минут?</span>
          <div className="mt-2 grid grid-cols-4 gap-2">
            {[10, 20, 40, 60].map((m) => (
              <button
                key={m}
                onClick={() => setGoal(m)}
                className={cn(
                  "rounded-xl border py-3 text-center transition-all",
                  goal === m ? "border-shu-500 bg-shu-50 text-shu-700" : "border-sumi-900/10 bg-white/70 text-sumi-700 hover:border-sumi-900/25",
                )}
              >
                <span className="block text-[18px] font-extrabold tabnum">{m}</span>
                <span className="text-[10.5px] font-bold">мин</span>
              </button>
            ))}
          </div>
        </div>
        <div className="grid gap-2 sm:grid-cols-2">
          <button
            onClick={() => {
              actions.setProfile({ name: name.trim(), dailyGoal: goal });
              onDone();
              go("kana");
            }}
            className="rounded-xl border border-sumi-900/12 bg-white/70 p-4 text-left transition hover:-translate-y-0.5 hover:border-matcha-500"
          >
            <span className="font-jp text-[22px] font-bold text-matcha-600">あ</span>
            <span className="mt-1 block text-[14px] font-extrabold text-sumi-900">Тэгээс эхэлнэ</span>
            <span className="text-[12px] text-sumi-500">Хираганаас эхлэх</span>
          </button>
          <button
            onClick={() => {
              actions.setProfile({ name: name.trim(), dailyGoal: goal });
              onDone();
              go("roadmap");
            }}
            className="rounded-xl border border-sumi-900/12 bg-white/70 p-4 text-left transition hover:-translate-y-0.5 hover:border-shu-500"
          >
            <span className="font-mincho text-[22px] font-bold text-shu-600">測</span>
            <span className="mt-1 block text-[14px] font-extrabold text-sumi-900">Түвшнээ тогтоох</span>
            <span className="text-[12px] text-sumi-500">15 асуулттай тест</span>
          </button>
        </div>
        <button
          onClick={() => {
            actions.setProfile({ name: name.trim(), dailyGoal: goal });
            onDone();
          }}
          className="w-full text-center text-[12.5px] font-bold text-sumi-500 underline-offset-4 hover:underline"
        >
          Дараа тохируулъя
        </button>
      </div>
    </Modal>
  );
}

function Settings({ onClose }: { onClose: () => void }) {
  const { state, actions } = useStore();
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [msg, setMsg] = useState("");
  const p = state.profile;

  const exportData = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `nihongo-dojo-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    setMsg("Нөөц файл татагдлаа.");
  };

  return (
    <Modal onClose={onClose}>
      <div className="flex items-center justify-between border-b border-sumi-900/10 px-6 py-5">
        <h2 className="text-[1.25rem] font-extrabold">Тохиргоо</h2>
        <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-lg bg-sumi-900/5" aria-label="Хаах">
          ✕
        </button>
      </div>
      <div className="space-y-6 px-6 py-6">
        <label className="block">
          <span className="text-[12.5px] font-bold text-sumi-700">Нэр</span>
          <input
            value={p.name}
            onChange={(e) => actions.setProfile({ name: e.target.value })}
            className="mt-1.5 h-11 w-full rounded-xl border border-sumi-900/15 bg-white px-4 text-[14px] font-semibold outline-none focus:border-shu-500"
          />
        </label>

        <div className="grid grid-cols-2 gap-4">
          <label className="block">
            <span className="text-[12.5px] font-bold text-sumi-700">Өдрийн зорилго (мин)</span>
            <input
              type="number"
              min={5}
              max={240}
              value={p.dailyGoal}
              onChange={(e) => actions.setProfile({ dailyGoal: Math.max(5, Number(e.target.value) || 20) })}
              className="mt-1.5 h-11 w-full rounded-xl border border-sumi-900/15 bg-white px-4 text-[14px] font-semibold outline-none focus:border-shu-500"
            />
          </label>
          <label className="block">
            <span className="text-[12.5px] font-bold text-sumi-700">Өдөрт шинэ карт</span>
            <input
              type="number"
              min={0}
              max={50}
              value={p.newPerDay}
              onChange={(e) => actions.setProfile({ newPerDay: Math.max(0, Number(e.target.value) || 0) })}
              className="mt-1.5 h-11 w-full rounded-xl border border-sumi-900/15 bg-white px-4 text-[14px] font-semibold outline-none focus:border-shu-500"
            />
          </label>
        </div>

        <div className="flex items-center justify-between rounded-xl border border-sumi-900/10 bg-white/60 px-4 py-3">
          <div>
            <p className="text-[13.5px] font-bold">Фуригана харуулах</p>
            <p className="text-[12px] text-sumi-500">Ханзын дээрх уншлага</p>
          </div>
          <button
            onClick={() => actions.setProfile({ furigana: !p.furigana })}
            className={cn("relative h-7 w-12 rounded-full transition-colors", p.furigana ? "bg-shu-500" : "bg-sumi-900/20")}
            aria-pressed={p.furigana}
          >
            <span className={cn("absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all", p.furigana ? "left-6" : "left-1")} />
          </button>
        </div>

        <label className="block">
          <span className="flex justify-between text-[12.5px] font-bold text-sumi-700">
            Дуудлагын хурд <span className="font-mono tabnum">{p.rate.toFixed(2)}×</span>
          </span>
          <input
            type="range"
            min={0.5}
            max={1.3}
            step={0.05}
            value={p.rate}
            onChange={(e) => actions.setProfile({ rate: Number(e.target.value) })}
            className="mt-2 w-full accent-shu-500"
          />
        </label>

        <div className="rounded-xl border border-sumi-900/10 bg-white/60 p-4">
          <p className="text-[13.5px] font-bold">Ахицын нөөц</p>
          <p className="mt-1 text-[12px] text-sumi-500">Бүх ахиц энэ төхөөрөмжийн хөтөч дээр хадгалагдана. Өөр төхөөрөмж рүү шилжүүлэхдээ файлаар нөөцөл.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button onClick={exportData} className="rounded-lg bg-sumi-900 px-3.5 py-2 text-[12.5px] font-bold text-washi-50">
              ↓ Татах (.json)
            </button>
            <button onClick={() => fileRef.current?.click()} className="rounded-lg border border-sumi-900/15 bg-white px-3.5 py-2 text-[12.5px] font-bold">
              ↑ Сэргээх
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json"
              className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                const ok = actions.importState(await f.text());
                setMsg(ok ? "Ахиц амжилттай сэргээгдлээ." : "Файл буруу байна.");
              }}
            />
            <button
              onClick={() => {
                if (window.confirm("Бүх ахицыг устгах уу? Буцаах боломжгүй.")) {
                  actions.reset();
                  onClose();
                }
              }}
              className="ml-auto rounded-lg px-3 py-2 text-[12.5px] font-bold text-shu-600 hover:bg-shu-50"
            >
              Бүгдийг арилгах
            </button>
          </div>
          {msg && <p className="mt-2 text-[12px] font-bold text-matcha-600">{msg}</p>}
        </div>
      </div>
    </Modal>
  );
}
