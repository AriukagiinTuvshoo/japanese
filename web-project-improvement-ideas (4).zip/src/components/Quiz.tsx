import { useEffect, useState } from "react";
import type { Question } from "../lib/exam";
import { useStore } from "../lib/store";
import { speak } from "../lib/speech";
import { Bar, Button, Card, OptionButton, Ruby, SpeakButton } from "./ui";
import { cn } from "../utils/cn";

export interface QuizResult {
  answers: (number | null)[];
  correct: number;
}

/** Хариулт бүрийн дараа шууд тайлбар харуулах сорил */
export default function Quiz({
  questions,
  title,
  onExit,
  onFinish,
  finishLabel = "Дуусгах",
  recordMistakes = true,
}: {
  questions: Question[];
  title: string;
  onExit: () => void;
  onFinish?: (r: QuizResult) => void;
  finishLabel?: string;
  recordMistakes?: boolean;
}) {
  const { state, actions } = useStore();
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(() => questions.map(() => null));
  const q = questions[i];
  const picked = answers[i];

  useEffect(() => {
    if (q?.speak) {
      const t = window.setTimeout(() => speak(q.speak!, state.profile.rate), 250);
      return () => window.clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i]);

  const pick = (k: number) => {
    if (picked !== null) return;
    const next = answers.slice();
    next[i] = k;
    setAnswers(next);
    if (k === q.answer) actions.addXP(2);
    else if (recordMistakes)
      actions.addMistakes([
        {
          id: q.id,
          kind: q.kindMn,
          level: q.level,
          prompt: q.speak ? `🔊 ${q.speak}` : q.prompt,
          answer: q.options[q.answer],
          given: q.options[k],
          note: q.explain,
        },
      ]);
  };

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (picked === null && ["1", "2", "3", "4"].includes(e.key)) pick(Number(e.key) - 1);
      if (picked !== null && (e.key === "Enter" || e.code === "Space")) {
        e.preventDefault();
        setI((x) => x + 1);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });

  if (!q) {
    const correct = questions.reduce((a, qq, k) => a + (answers[k] === qq.answer ? 1 : 0), 0);
    const pct = Math.round((correct / Math.max(1, questions.length)) * 100);
    return (
      <Card className="mx-auto max-w-xl animate-pop p-8 text-center">
        <p className={cn("font-mincho text-[3.6rem] font-black leading-none", pct >= 80 ? "text-matcha-500" : pct >= 60 ? "text-kin-500" : "text-shu-500")}>
          {pct >= 80 ? "合格" : pct >= 60 ? "惜しい" : "再挑戦"}
        </p>
        <h2 className="mt-3 text-[1.6rem] font-extrabold tabnum">
          {correct}/{questions.length} · {pct}%
        </h2>
        <p className="mt-1 text-[13px] text-sumi-500">Буруу хариулсан асуултууд алдааны дэвтэрт хадгалагдлаа.</p>
        <div className="mt-7 grid grid-cols-2 gap-2">
          <Button variant="outline" onClick={onExit}>
            Буцах
          </Button>
          <Button onClick={() => (onFinish ? onFinish({ answers, correct }) : onExit())}>{finishLabel}</Button>
        </div>
      </Card>
    );
  }

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-4 flex items-center gap-3">
        <button onClick={onExit} className="grid h-9 w-9 place-items-center rounded-xl border border-sumi-900/10 bg-white/70" aria-label="Гарах">
          ✕
        </button>
        <div className="flex-1">
          <div className="mb-1.5 flex justify-between text-[12px] font-bold text-sumi-500">
            <span>{title}</span>
            <span className="tabnum">
              {i + 1}/{questions.length}
            </span>
          </div>
          <Bar value={i / questions.length} />
        </div>
      </div>

      <QuestionView q={q} />

      <div className="mt-4 grid gap-2">
        {q.options.map((o, k) => (
          <OptionButton
            key={k}
            idx={k}
            disabled={picked !== null}
            onClick={() => pick(k)}
            state={picked === null ? "idle" : k === q.answer ? "correct" : k === picked ? "wrong" : "dim"}
          >
            <Ruby text={o} />
          </OptionButton>
        ))}
      </div>

      {picked !== null && (
        <div className={cn("mt-4 animate-rise rounded-xl border p-4", picked === q.answer ? "border-matcha-400/50 bg-matcha-50" : "border-shu-400/50 bg-shu-50")}>
          <p className={cn("text-[13px] font-extrabold", picked === q.answer ? "text-matcha-600" : "text-shu-600")}>
            {picked === q.answer ? "✓ Зөв!" : "✕ Буруу"}
          </p>
          <p className="mt-1 font-jp text-[14px] leading-relaxed text-sumi-700">{q.explain}</p>
          <Button className="mt-3 w-full" variant="ink" onClick={() => setI((x) => x + 1)}>
            Дараах <span className="font-mono text-[11px] opacity-60">Enter</span>
          </Button>
        </div>
      )}
    </div>
  );
}

export function QuestionView({ q }: { q: Question }) {
  const { state } = useStore();
  return (
    <Card className="overflow-hidden">
      <div className="flex items-center gap-2 border-b border-sumi-900/[0.07] bg-white/50 px-5 py-3">
        <span className="rounded-md bg-sumi-900 px-2 py-0.5 font-jp text-[11.5px] font-bold text-washi-50">{q.kind}</span>
        <span className="text-[12px] font-bold text-sumi-500">{q.kindMn}</span>
        <span className="ml-auto font-mono text-[11px] font-bold text-sumi-400">{q.level}</span>
      </div>

      {q.passage && (
        <div className="max-h-[38vh] overflow-y-auto border-b border-sumi-900/[0.07] bg-washi-50 px-5 py-5">
          <p className="mb-2 font-jp text-[15px] font-bold">
            <Ruby text={q.passage.title} />
          </p>
          <p className="font-jp text-[15.5px] leading-[2.15] text-sumi-800">
            <Ruby text={q.passage.text} />
          </p>
        </div>
      )}

      <div className="px-5 py-7 text-center sm:px-8">
        {q.speak ? (
          <div className="flex flex-col items-center gap-3">
            <button
              onClick={() => speak(q.speak!, state.profile.rate)}
              className="grid h-20 w-20 place-items-center rounded-full bg-shu-500 text-white shadow-[0_14px_30px_-14px_rgba(204,70,48,0.9)] transition-transform hover:scale-105 active:scale-95"
              aria-label="Сонсох"
            >
              <svg viewBox="0 0 24 24" className="h-8 w-8" fill="currentColor">
                <path d="M11 5 6 9H3v6h3l5 4V5Z" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </button>
            <p className="text-[13px] font-bold text-sumi-500">Сонсоод утгыг нь сонго · дахин сонсох бол дар</p>
          </div>
        ) : (
          <div className="flex items-center justify-center gap-3">
            <Ruby
              text={q.prompt}
              className={cn("text-sumi-900", q.big ? "text-[clamp(2.2rem,7vw,3.4rem)] font-black" : "text-[clamp(1.15rem,3vw,1.45rem)] font-bold leading-[2]")}
            />
            {q.big && q.section === "vocab" && q.kind === "語彙" && <SpeakButton text={q.prompt.replace(/.*\{|\}/g, "")} size="sm" />}
          </div>
        )}
      </div>
    </Card>
  );
}
