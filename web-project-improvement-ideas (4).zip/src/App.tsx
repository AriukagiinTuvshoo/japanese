import Shell, { useRoute } from "./components/Shell";
import { StoreProvider } from "./lib/store";
import Home from "./pages/Home";
import Roadmap from "./pages/Roadmap";
import Kana from "./pages/Kana";
import Vocab from "./pages/Vocab";
import Kanji from "./pages/Kanji";
import Grammar from "./pages/Grammar";
import Reading from "./pages/Reading";
import Listening from "./pages/Listening";
import Exam from "./pages/Exam";
import Plan from "./pages/Plan";
import Mistakes from "./pages/Mistakes";

function Router() {
  const [route, go] = useRoute();
  const page = {
    home: <Home go={go} />,
    roadmap: <Roadmap go={go} />,
    kana: <Kana />,
    vocab: <Vocab />,
    kanji: <Kanji />,
    grammar: <Grammar />,
    reading: <Reading />,
    listening: <Listening />,
    exam: <Exam />,
    plan: <Plan />,
    mistakes: <Mistakes go={go} />,
  }[route];
  return (
    <Shell route={route} go={go}>
      {page}
    </Shell>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Router />
    </StoreProvider>
  );
}
